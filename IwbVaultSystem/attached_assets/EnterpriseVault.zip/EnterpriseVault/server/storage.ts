import { 
  users, type User, type InsertUser,
  productCategories, type ProductCategory, type InsertProductCategory,
  products, type Product, type InsertProduct,
  sales, type Sale, type InsertSale,
  customerQueries, type CustomerQuery, type InsertCustomerQuery,
  financeRecords, type FinanceRecord, type InsertFinanceRecord,
  incomeStatements, type IncomeStatement, type InsertIncomeStatement,
  queryResponses, type QueryResponse, type InsertQueryResponse,
  activityLogs, type ActivityLog, type InsertActivityLog,
  backups, type Backup, type InsertBackup
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import connectPg from "connect-pg-simple";
import session from "express-session";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User>;
  getAllUsers(): Promise<User[]>;
  
  // Product categories
  createProductCategory(category: InsertProductCategory): Promise<ProductCategory>;
  getProductCategory(id: number): Promise<ProductCategory | undefined>;
  getAllProductCategories(tenantId?: number): Promise<ProductCategory[]>;
  
  // Products
  createProduct(product: InsertProduct): Promise<Product>;
  getProduct(id: number): Promise<Product | undefined>;
  updateProduct(id: number, updates: Partial<Product>): Promise<Product>;
  getAllProducts(tenantId?: number): Promise<Product[]>;
  
  // Sales
  createSale(sale: InsertSale): Promise<Sale>;
  getSale(id: number): Promise<Sale | undefined>;
  getAllSales(tenantId?: number): Promise<Sale[]>;
  
  // Customer queries
  createCustomerQuery(query: InsertCustomerQuery): Promise<CustomerQuery>;
  getCustomerQuery(id: number): Promise<CustomerQuery | undefined>;
  updateCustomerQuery(id: number, updates: Partial<CustomerQuery>): Promise<CustomerQuery>;
  getAllCustomerQueries(tenantId?: number): Promise<CustomerQuery[]>;
  
  // Finance records
  createFinanceRecord(record: InsertFinanceRecord): Promise<FinanceRecord>;
  getFinanceRecord(id: number): Promise<FinanceRecord | undefined>;
  getAllFinanceRecords(tenantId?: number): Promise<FinanceRecord[]>;
  getFinanceRecordsByType(type: string, month?: number, year?: number, tenantId?: number): Promise<FinanceRecord[]>;
  
  // Income statements
  createIncomeStatement(statement: InsertIncomeStatement): Promise<IncomeStatement>;
  getIncomeStatement(id: number): Promise<IncomeStatement | undefined>;
  getAllIncomeStatements(tenantId?: number): Promise<IncomeStatement[]>;
  
  // Query responses for NLP
  createQueryResponse(response: InsertQueryResponse): Promise<QueryResponse>;
  getAllQueryResponses(): Promise<QueryResponse[]>;
  updateQueryResponseFrequency(id: number): Promise<QueryResponse>;
  
  // Activity logs
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  getAllActivityLogs(tenantId?: number): Promise<ActivityLog[]>;
  
  // Backups
  createBackup(backup: InsertBackup): Promise<Backup>;
  getAllBackups(): Promise<Backup[]>;
  
  // Session store
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private usersMap: Map<number, User>;
  private productCategoriesMap: Map<number, ProductCategory>;
  private productsMap: Map<number, Product>;
  private salesMap: Map<number, Sale>;
  private customerQueriesMap: Map<number, CustomerQuery>;
  private financeRecordsMap: Map<number, FinanceRecord>;
  private incomeStatementsMap: Map<number, IncomeStatement>;
  private queryResponsesMap: Map<number, QueryResponse>;
  private activityLogsMap: Map<number, ActivityLog>;
  private backupsMap: Map<number, Backup>;
  
  sessionStore: session.Store;
  
  currentIds: {
    user: number;
    productCategory: number;
    product: number;
    sale: number;
    customerQuery: number;
    financeRecord: number;
    incomeStatement: number;
    queryResponse: number;
    activityLog: number;
    backup: number;
  };

  constructor() {
    this.usersMap = new Map();
    this.productCategoriesMap = new Map();
    this.productsMap = new Map();
    this.salesMap = new Map();
    this.customerQueriesMap = new Map();
    this.financeRecordsMap = new Map();
    this.incomeStatementsMap = new Map();
    this.queryResponsesMap = new Map();
    this.activityLogsMap = new Map();
    this.backupsMap = new Map();
    
    this.currentIds = {
      user: 1,
      productCategory: 1,
      product: 1,
      sale: 1,
      customerQuery: 1,
      financeRecord: 1,
      incomeStatement: 1,
      queryResponse: 1,
      activityLog: 1,
      backup: 1
    };
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24 hours
    });
    
    // Initialize with some seed data for developer role
    this.createUser({
      username: "admin",
      password: "admin123", // This will be hashed in auth.ts
      email: "admin@iwb.com",
      fullName: "Admin User",
      role: "developer",
      tenantId: 1
    });
  }

  // User management
  async getUser(id: number): Promise<User | undefined> {
    return this.usersMap.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.usersMap.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.usersMap.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentIds.user++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: now,
      mfaEnabled: false
    };
    this.usersMap.set(id, user);
    return user;
  }
  
  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with ID ${id} not found`);
    }
    
    const updatedUser = { ...user, ...updates };
    this.usersMap.set(id, updatedUser);
    return updatedUser;
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.usersMap.values());
  }
  
  // Product categories
  async createProductCategory(category: InsertProductCategory): Promise<ProductCategory> {
    const id = this.currentIds.productCategory++;
    const newCategory: ProductCategory = { ...category, id };
    this.productCategoriesMap.set(id, newCategory);
    return newCategory;
  }
  
  async getProductCategory(id: number): Promise<ProductCategory | undefined> {
    return this.productCategoriesMap.get(id);
  }
  
  async getAllProductCategories(tenantId?: number): Promise<ProductCategory[]> {
    let categories = Array.from(this.productCategoriesMap.values());
    if (tenantId) {
      categories = categories.filter(cat => cat.tenantId === tenantId);
    }
    return categories;
  }
  
  // Products
  async createProduct(product: InsertProduct): Promise<Product> {
    const id = this.currentIds.product++;
    const now = new Date();
    const newProduct: Product = { 
      ...product, 
      id,
      createdAt: now,
      updatedAt: now
    };
    this.productsMap.set(id, newProduct);
    return newProduct;
  }
  
  async getProduct(id: number): Promise<Product | undefined> {
    return this.productsMap.get(id);
  }
  
  async updateProduct(id: number, updates: Partial<Product>): Promise<Product> {
    const product = await this.getProduct(id);
    if (!product) {
      throw new Error(`Product with ID ${id} not found`);
    }
    
    const updatedProduct = { 
      ...product, 
      ...updates,
      updatedAt: new Date()
    };
    this.productsMap.set(id, updatedProduct);
    return updatedProduct;
  }
  
  async getAllProducts(tenantId?: number): Promise<Product[]> {
    let products = Array.from(this.productsMap.values());
    if (tenantId) {
      products = products.filter(prod => prod.tenantId === tenantId);
    }
    return products;
  }
  
  // Sales
  async createSale(sale: InsertSale): Promise<Sale> {
    const id = this.currentIds.sale++;
    const now = new Date();
    const newSale: Sale = { 
      ...sale, 
      id,
      date: now
    };
    this.salesMap.set(id, newSale);
    return newSale;
  }
  
  async getSale(id: number): Promise<Sale | undefined> {
    return this.salesMap.get(id);
  }
  
  async getAllSales(tenantId?: number): Promise<Sale[]> {
    let sales = Array.from(this.salesMap.values());
    if (tenantId) {
      sales = sales.filter(sale => sale.tenantId === tenantId);
    }
    return sales;
  }
  
  // Customer queries
  async createCustomerQuery(query: InsertCustomerQuery): Promise<CustomerQuery> {
    const id = this.currentIds.customerQuery++;
    const now = new Date();
    const newQuery: CustomerQuery = { 
      ...query, 
      id,
      status: "pending",
      createdAt: now,
      updatedAt: now,
      tenantId: query.tenantId || 1
    };
    this.customerQueriesMap.set(id, newQuery);
    return newQuery;
  }
  
  async getCustomerQuery(id: number): Promise<CustomerQuery | undefined> {
    return this.customerQueriesMap.get(id);
  }
  
  async updateCustomerQuery(id: number, updates: Partial<CustomerQuery>): Promise<CustomerQuery> {
    const query = await this.getCustomerQuery(id);
    if (!query) {
      throw new Error(`Customer query with ID ${id} not found`);
    }
    
    const updatedQuery = { 
      ...query, 
      ...updates,
      updatedAt: new Date()
    };
    this.customerQueriesMap.set(id, updatedQuery);
    return updatedQuery;
  }
  
  async getAllCustomerQueries(tenantId?: number): Promise<CustomerQuery[]> {
    let queries = Array.from(this.customerQueriesMap.values());
    if (tenantId) {
      queries = queries.filter(query => query.tenantId === tenantId);
    }
    return queries;
  }
  
  // Finance records
  async createFinanceRecord(record: InsertFinanceRecord): Promise<FinanceRecord> {
    const id = this.currentIds.financeRecord++;
    const now = new Date();
    const newRecord: FinanceRecord = { 
      ...record, 
      id,
      date: now
    };
    this.financeRecordsMap.set(id, newRecord);
    return newRecord;
  }
  
  async getFinanceRecord(id: number): Promise<FinanceRecord | undefined> {
    return this.financeRecordsMap.get(id);
  }
  
  async getAllFinanceRecords(tenantId?: number): Promise<FinanceRecord[]> {
    let records = Array.from(this.financeRecordsMap.values());
    if (tenantId) {
      records = records.filter(record => record.tenantId === tenantId);
    }
    return records;
  }
  
  async getFinanceRecordsByType(type: string, month?: number, year?: number, tenantId?: number): Promise<FinanceRecord[]> {
    let records = await this.getAllFinanceRecords(tenantId);
    
    // Filter by type
    records = records.filter(record => record.type === type);
    
    // If month and year are provided, filter by them
    if (month && year) {
      records = records.filter(record => {
        const recordDate = new Date(record.date);
        return recordDate.getMonth() + 1 === month && recordDate.getFullYear() === year;
      });
    }
    
    return records;
  }
  
  // Income statements
  async createIncomeStatement(statement: InsertIncomeStatement): Promise<IncomeStatement> {
    const id = this.currentIds.incomeStatement++;
    const now = new Date();
    const newStatement: IncomeStatement = { 
      ...statement, 
      id,
      generatedAt: now
    };
    this.incomeStatementsMap.set(id, newStatement);
    return newStatement;
  }
  
  async getIncomeStatement(id: number): Promise<IncomeStatement | undefined> {
    return this.incomeStatementsMap.get(id);
  }
  
  async getAllIncomeStatements(tenantId?: number): Promise<IncomeStatement[]> {
    let statements = Array.from(this.incomeStatementsMap.values());
    if (tenantId) {
      statements = statements.filter(statement => statement.tenantId === tenantId);
    }
    return statements;
  }
  
  // Query responses for NLP
  async createQueryResponse(response: InsertQueryResponse): Promise<QueryResponse> {
    const id = this.currentIds.queryResponse++;
    const now = new Date();
    const newResponse: QueryResponse = { 
      ...response, 
      id,
      frequency: 1,
      lastUsed: now
    };
    this.queryResponsesMap.set(id, newResponse);
    return newResponse;
  }
  
  async getAllQueryResponses(): Promise<QueryResponse[]> {
    return Array.from(this.queryResponsesMap.values());
  }
  
  async updateQueryResponseFrequency(id: number): Promise<QueryResponse> {
    const response = await this.queryResponsesMap.get(id);
    if (!response) {
      throw new Error(`Query response with ID ${id} not found`);
    }
    
    const updatedResponse = { 
      ...response, 
      frequency: response.frequency + 1,
      lastUsed: new Date()
    };
    this.queryResponsesMap.set(id, updatedResponse);
    return updatedResponse;
  }
  
  // Activity logs
  async createActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const id = this.currentIds.activityLog++;
    const now = new Date();
    const newLog: ActivityLog = { 
      ...log, 
      id,
      timestamp: now
    };
    this.activityLogsMap.set(id, newLog);
    return newLog;
  }
  
  async getAllActivityLogs(tenantId?: number): Promise<ActivityLog[]> {
    let logs = Array.from(this.activityLogsMap.values());
    if (tenantId) {
      logs = logs.filter(log => log.tenantId === tenantId);
    }
    return logs;
  }
  
  // Backups
  async createBackup(backup: InsertBackup): Promise<Backup> {
    const id = this.currentIds.backup++;
    const now = new Date();
    const newBackup: Backup = { 
      ...backup, 
      id,
      createdAt: now
    };
    this.backupsMap.set(id, newBackup);
    return newBackup;
  }
  
  async getAllBackups(): Promise<Backup[]> {
    return Array.from(this.backupsMap.values());
  }
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool,
      createTableIfMissing: true
    });
  }

  // User management
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, username));
    return user;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const now = new Date();
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        createdAt: now,
        mfaEnabled: false
      })
      .returning();
    return user;
  }
  
  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    
    if (!updatedUser) {
      throw new Error(`User with ID ${id} not found`);
    }
    
    return updatedUser;
  }
  
  async getAllUsers(): Promise<User[]> {
    return db.select().from(users);
  }
  
  // Product categories
  async createProductCategory(category: InsertProductCategory): Promise<ProductCategory> {
    const [newCategory] = await db
      .insert(productCategories)
      .values(category)
      .returning();
    return newCategory;
  }
  
  async getProductCategory(id: number): Promise<ProductCategory | undefined> {
    const [category] = await db
      .select()
      .from(productCategories)
      .where(eq(productCategories.id, id));
    return category;
  }
  
  async getAllProductCategories(tenantId?: number): Promise<ProductCategory[]> {
    if (tenantId) {
      return db
        .select()
        .from(productCategories)
        .where(eq(productCategories.tenantId, tenantId));
    }
    return db.select().from(productCategories);
  }
  
  // Products
  async createProduct(product: InsertProduct): Promise<Product> {
    const now = new Date();
    const [newProduct] = await db
      .insert(products)
      .values({
        ...product,
        createdAt: now,
        updatedAt: now
      })
      .returning();
    return newProduct;
  }
  
  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db
      .select()
      .from(products)
      .where(eq(products.id, id));
    return product;
  }
  
  async updateProduct(id: number, updates: Partial<Product>): Promise<Product> {
    const [updatedProduct] = await db
      .update(products)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(products.id, id))
      .returning();
    
    if (!updatedProduct) {
      throw new Error(`Product with ID ${id} not found`);
    }
    
    return updatedProduct;
  }
  
  async getAllProducts(tenantId?: number): Promise<Product[]> {
    if (tenantId) {
      return db
        .select()
        .from(products)
        .where(eq(products.tenantId, tenantId));
    }
    return db.select().from(products);
  }
  
  // Sales
  async createSale(sale: InsertSale): Promise<Sale> {
    const now = new Date();
    const [newSale] = await db
      .insert(sales)
      .values({
        ...sale,
        date: sale.date || now
      })
      .returning();
    return newSale;
  }
  
  async getSale(id: number): Promise<Sale | undefined> {
    const [sale] = await db
      .select()
      .from(sales)
      .where(eq(sales.id, id));
    return sale;
  }
  
  async getAllSales(tenantId?: number): Promise<Sale[]> {
    if (tenantId) {
      return db
        .select()
        .from(sales)
        .where(eq(sales.tenantId, tenantId));
    }
    return db.select().from(sales);
  }
  
  // Customer queries
  async createCustomerQuery(query: InsertCustomerQuery): Promise<CustomerQuery> {
    const now = new Date();
    const [newQuery] = await db
      .insert(customerQueries)
      .values({
        ...query,
        status: "pending",
        createdAt: now,
        updatedAt: now,
        tenantId: query.tenantId || 1
      })
      .returning();
    return newQuery;
  }
  
  async getCustomerQuery(id: number): Promise<CustomerQuery | undefined> {
    const [query] = await db
      .select()
      .from(customerQueries)
      .where(eq(customerQueries.id, id));
    return query;
  }
  
  async updateCustomerQuery(id: number, updates: Partial<CustomerQuery>): Promise<CustomerQuery> {
    const [updatedQuery] = await db
      .update(customerQueries)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(customerQueries.id, id))
      .returning();
    
    if (!updatedQuery) {
      throw new Error(`Customer query with ID ${id} not found`);
    }
    
    return updatedQuery;
  }
  
  async getAllCustomerQueries(tenantId?: number): Promise<CustomerQuery[]> {
    if (tenantId) {
      return db
        .select()
        .from(customerQueries)
        .where(eq(customerQueries.tenantId, tenantId));
    }
    return db.select().from(customerQueries);
  }
  
  // Finance records
  async createFinanceRecord(record: InsertFinanceRecord): Promise<FinanceRecord> {
    const now = new Date();
    const [newRecord] = await db
      .insert(financeRecords)
      .values({
        ...record,
        date: record.date || now
      })
      .returning();
    return newRecord;
  }
  
  async getFinanceRecord(id: number): Promise<FinanceRecord | undefined> {
    const [record] = await db
      .select()
      .from(financeRecords)
      .where(eq(financeRecords.id, id));
    return record;
  }
  
  async getAllFinanceRecords(tenantId?: number): Promise<FinanceRecord[]> {
    if (tenantId) {
      return db
        .select()
        .from(financeRecords)
        .where(eq(financeRecords.tenantId, tenantId));
    }
    return db.select().from(financeRecords);
  }
  
  async getFinanceRecordsByType(type: string, month?: number, year?: number, tenantId?: number): Promise<FinanceRecord[]> {
    let query = db.select().from(financeRecords).where(eq(financeRecords.type, type));
    
    if (tenantId) {
      query = query.where(eq(financeRecords.tenantId, tenantId));
    }
    
    // Month and year filtering would need custom SQL filtering which is beyond the scope of this example
    return query;
  }
  
  // Income statements
  async createIncomeStatement(statement: InsertIncomeStatement): Promise<IncomeStatement> {
    const now = new Date();
    const [newStatement] = await db
      .insert(incomeStatements)
      .values({
        ...statement,
        generatedAt: now
      })
      .returning();
    return newStatement;
  }
  
  async getIncomeStatement(id: number): Promise<IncomeStatement | undefined> {
    const [statement] = await db
      .select()
      .from(incomeStatements)
      .where(eq(incomeStatements.id, id));
    return statement;
  }
  
  async getAllIncomeStatements(tenantId?: number): Promise<IncomeStatement[]> {
    if (tenantId) {
      return db
        .select()
        .from(incomeStatements)
        .where(eq(incomeStatements.tenantId, tenantId));
    }
    return db.select().from(incomeStatements);
  }
  
  // Query responses for NLP
  async createQueryResponse(response: InsertQueryResponse): Promise<QueryResponse> {
    const now = new Date();
    const [newResponse] = await db
      .insert(queryResponses)
      .values({
        ...response,
        frequency: 1,
        lastUsed: now
      })
      .returning();
    return newResponse;
  }
  
  async getAllQueryResponses(): Promise<QueryResponse[]> {
    return db.select().from(queryResponses);
  }
  
  async updateQueryResponseFrequency(id: number): Promise<QueryResponse> {
    const [response] = await db
      .select()
      .from(queryResponses)
      .where(eq(queryResponses.id, id));
    
    if (!response) {
      throw new Error(`Query response with ID ${id} not found`);
    }
    
    const [updatedResponse] = await db
      .update(queryResponses)
      .set({
        frequency: response.frequency + 1,
        lastUsed: new Date()
      })
      .where(eq(queryResponses.id, id))
      .returning();
    
    return updatedResponse;
  }
  
  // Activity logs
  async createActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const now = new Date();
    const [newLog] = await db
      .insert(activityLogs)
      .values({
        ...log,
        timestamp: now
      })
      .returning();
    return newLog;
  }
  
  async getAllActivityLogs(tenantId?: number): Promise<ActivityLog[]> {
    if (tenantId) {
      return db
        .select()
        .from(activityLogs)
        .where(eq(activityLogs.tenantId, tenantId));
    }
    return db.select().from(activityLogs);
  }
  
  // Backups
  async createBackup(backup: InsertBackup): Promise<Backup> {
    const now = new Date();
    const [newBackup] = await db
      .insert(backups)
      .values({
        ...backup,
        createdAt: now
      })
      .returning();
    return newBackup;
  }
  
  async getAllBackups(): Promise<Backup[]> {
    return db.select().from(backups);
  }
}

// Switch from MemStorage to DatabaseStorage for persistence
export const storage = new DatabaseStorage();
