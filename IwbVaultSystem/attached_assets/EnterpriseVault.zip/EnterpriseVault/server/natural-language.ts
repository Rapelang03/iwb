import { storage } from "./storage";

// Simple text similarity function using Jaccard similarity
function calculateSimilarity(text1: string, text2: string): number {
  // Tokenize and normalize the texts
  const tokens1 = text1.toLowerCase().split(/\W+/).filter(token => token.length > 0);
  const tokens2 = text2.toLowerCase().split(/\W+/).filter(token => token.length > 0);
  
  // Create sets for unique tokens
  const set1 = new Set(tokens1);
  const set2 = new Set(tokens2);
  
  // Calculate intersection
  const intersection = new Set([...set1].filter(token => set2.has(token)));
  
  // Calculate union
  const union = new Set([...set1, ...set2]);
  
  // Jaccard similarity: intersection size / union size
  return intersection.size / union.size;
}

// Find similar queries and their responses
export async function generateResponse(queryText: string): Promise<string | null> {
  try {
    // Get all existing query responses
    const queryResponses = await storage.getAllQueryResponses();
    
    if (queryResponses.length === 0) {
      return null;
    }
    
    // Find the most similar query
    let maxSimilarity = 0;
    let bestMatch = null;
    
    for (const response of queryResponses) {
      const similarity = calculateSimilarity(queryText, response.query);
      
      // Consider a match if similarity is above threshold and better than previous matches
      if (similarity > 0.7 && similarity > maxSimilarity) {
        maxSimilarity = similarity;
        bestMatch = response;
      }
    }
    
    // If a good match was found, update its frequency and return the response
    if (bestMatch) {
      await storage.updateQueryResponseFrequency(bestMatch.id);
      return bestMatch.response;
    }
    
    return null;
  } catch (error) {
    console.error("Error generating response:", error);
    return null;
  }
}

// Update or create query-response pairs 
export async function updateQueryResponses(query: string, response: string): Promise<void> {
  try {
    // Get existing responses to check for similar queries
    const queryResponses = await storage.getAllQueryResponses();
    
    // Look for existing similar queries
    let maxSimilarity = 0;
    let bestMatch = null;
    
    for (const resp of queryResponses) {
      const similarity = calculateSimilarity(query, resp.query);
      if (similarity > 0.9 && similarity > maxSimilarity) {
        maxSimilarity = similarity;
        bestMatch = resp;
      }
    }
    
    // If very similar query exists, update its frequency
    if (bestMatch) {
      await storage.updateQueryResponseFrequency(bestMatch.id);
    } else {
      // Otherwise create a new query-response pair
      await storage.createQueryResponse({
        query,
        response,
        tenantId: 1 // Default tenant
      });
    }
  } catch (error) {
    console.error("Error updating query responses:", error);
  }
}
