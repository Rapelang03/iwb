import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express, Request, Response, NextFunction } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";
import { authenticator } from "otplib";

// For TypeScript to correctly type req.user
declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

// Hash password function
async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

// Compare passwords function
async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

// Middleware to ensure MFA is completed if enabled
function ensureMFACompleted(req: Request, res: Response, next: NextFunction) {
  // If user doesn't have MFA enabled, proceed
  if (!req.user?.mfaEnabled) {
    return next();
  }
  
  // If MFA is enabled, check if the session has a flag showing MFA was verified
  if (req.session.mfaVerified) {
    return next();
  }
  
  // Otherwise, require MFA
  return res.status(401).json({ 
    message: "MFA verification required",
    requiresMFA: true
  });
}

export function setupAuth(app: Express) {
  // Set up session
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "iwb-recycling-platform-secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  // Set up local strategy for username/password auth
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        // Check if user exists (by username or email)
        let user = await storage.getUserByUsername(username);
        if (!user) {
          user = await storage.getUserByEmail(username);
        }
        
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false, { message: "Invalid username or password" });
        }
        
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }),
  );

  // Serialize and deserialize user for session management
  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Register new user
  app.post("/api/register", async (req, res, next) => {
    try {
      // Check if username or email already exists
      const existingUserByUsername = await storage.getUserByUsername(req.body.username);
      if (existingUserByUsername) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const existingUserByEmail = await storage.getUserByEmail(req.body.email);
      if (existingUserByEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      // Create user with hashed password
      const user = await storage.createUser({
        ...req.body,
        password: await hashPassword(req.body.password),
        role: req.body.role || "client", // Default role is client
      });
      
      // Remove password from response
      const userResponse = { ...user, password: undefined };
      
      // Log the user in after registration
      req.login(user, (err) => {
        if (err) return next(err);
        
        // Since it's a new user, they won't have MFA enabled yet
        req.session.mfaVerified = true;
        
        res.status(201).json(userResponse);
      });
    } catch (error) {
      next(error);
    }
  });

  // Login endpoint
  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) return next(err);
      if (!user) {
        return res.status(401).json({ message: info?.message || "Authentication failed" });
      }
      
      req.login(user, (err) => {
        if (err) return next(err);
        
        // If MFA is enabled, don't set mfaVerified yet and return with MFA required flag
        if (user.mfaEnabled) {
          return res.status(200).json({ 
            message: "MFA verification required", 
            requiresMFA: true,
            user: { ...user, password: undefined }
          });
        }
        
        // If no MFA, mark as verified
        req.session.mfaVerified = true;
        
        // Return user without password
        res.status(200).json({ ...user, password: undefined });
      });
    })(req, res, next);
  });

  // Logout endpoint
  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      req.session.destroy(() => {
        res.sendStatus(200);
      });
    });
  });

  // Get current user
  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    // Check if MFA is required but not completed
    if (req.user?.mfaEnabled && !req.session.mfaVerified) {
      return res.status(401).json({ 
        message: "MFA verification required",
        requiresMFA: true
      });
    }
    
    // Return user without password
    const userResponse = { ...req.user, password: undefined };
    res.json(userResponse);
  });

  // Setup MFA
  app.post("/api/mfa/setup", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      // Generate MFA secret
      const secret = authenticator.generateSecret();
      
      // Update user with secret but don't enable MFA yet
      await storage.updateUser(req.user!.id, {
        mfaSecret: secret
      });
      
      // Get user info for QR code generation
      const issuer = "IWB Recycling Platform";
      const accountName = req.user!.email;
      const otpAuthUrl = authenticator.keyuri(accountName, issuer, secret);
      
      res.json({
        secret,
        otpAuthUrl
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to setup MFA" });
    }
  });

  // Verify MFA token
  app.post("/api/mfa/verify", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const { token, isEnabling } = req.body;
    
    try {
      // Get user's MFA secret
      const user = await storage.getUser(req.user!.id);
      if (!user || !user.mfaSecret) {
        return res.status(400).json({ message: "MFA not setup for this user" });
      }
      
      // Verify token
      const isValid = authenticator.verify({ 
        token, 
        secret: user.mfaSecret 
      });
      
      if (!isValid) {
        return res.status(401).json({ message: "Invalid MFA token" });
      }
      
      // Mark session as MFA verified
      req.session.mfaVerified = true;
      
      // If this is the first verification after setup, enable MFA for the user
      if (isEnabling) {
        await storage.updateUser(user.id, { mfaEnabled: true });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to verify MFA token" });
    }
  });

  // Disable MFA
  app.post("/api/mfa/disable", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    // Only allow if MFA is already verified in this session
    if (!req.session.mfaVerified) {
      return res.status(401).json({ message: "MFA verification required" });
    }
    
    try {
      await storage.updateUser(req.user!.id, {
        mfaEnabled: false,
        mfaSecret: null
      });
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to disable MFA" });
    }
  });

  // Add MFA middleware to protect all other API routes
  app.use("/api/*", (req, res, next) => {
    // Skip MFA check for auth-related endpoints
    if (
      req.path === "/api/login" ||
      req.path === "/api/register" ||
      req.path === "/api/logout" ||
      req.path === "/api/user" ||
      req.path.startsWith("/api/mfa/")
    ) {
      return next();
    }
    
    ensureMFACompleted(req, res, next);
  });
}
