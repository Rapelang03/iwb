import fs from 'fs/promises';
import path from 'path';
import { storage } from './storage';

// Directory where backups will be stored
const BACKUP_DIR = process.env.BACKUP_DIR || path.join(process.cwd(), 'backups');

// Ensure backup directory exists
async function ensureBackupDir() {
  try {
    await fs.mkdir(BACKUP_DIR, { recursive: true });
  } catch (error) {
    console.error('Error creating backup directory:', error);
    throw new Error('Failed to create backup directory');
  }
}

// Create a backup of all data
export async function backupData(userId: number) {
  await ensureBackupDir();
  
  try {
    // Get all data from storage
    const users = await storage.getAllUsers();
    const products = await storage.getAllProducts();
    const categories = await storage.getAllProductCategories();
    const sales = await storage.getAllSales();
    const queries = await storage.getAllCustomerQueries();
    const financeRecords = await storage.getAllFinanceRecords();
    const incomeStatements = await storage.getAllIncomeStatements();
    const queryResponses = await storage.getAllQueryResponses();
    const logs = await storage.getAllActivityLogs();
    
    // Create backup object with all data
    const backupData = {
      timestamp: new Date().toISOString(),
      users: users.map(user => ({ ...user, password: '[REDACTED]' })), // Don't backup actual passwords
      products,
      categories,
      sales,
      queries,
      financeRecords,
      incomeStatements,
      queryResponses,
      logs
    };
    
    // Generate filename with timestamp
    const timestamp = new Date().toISOString().replace(/:/g, '-').replace(/\..+/, '');
    const filename = `backup_${timestamp}.json`;
    const filePath = path.join(BACKUP_DIR, filename);
    
    // Write backup to file
    const dataString = JSON.stringify(backupData, null, 2);
    await fs.writeFile(filePath, dataString, 'utf8');
    
    // Get file size
    const stats = await fs.stat(filePath);
    
    // Record backup in database
    const backup = await storage.createBackup({
      filename,
      size: stats.size,
      createdById: userId,
      status: 'completed',
      backupType: 'full',
      location: `local://${filePath}`,
      tenantId: 1
    });
    
    return {
      success: true,
      backup
    };
  } catch (error) {
    console.error('Error creating backup:', error);
    
    // Record failed backup
    const backup = await storage.createBackup({
      filename: `failed_backup_${new Date().toISOString()}`,
      size: 0,
      createdById: userId,
      status: 'failed',
      backupType: 'full',
      location: 'local://failed',
      tenantId: 1
    });
    
    return {
      success: false,
      error: 'Failed to create backup',
      backup
    };
  }
}

// Get all backup records
export async function getBackups() {
  return storage.getAllBackups();
}

// Restore from a backup (for future implementation)
export async function restoreFromBackup(backupId: number) {
  // Implementation would:
  // 1. Retrieve backup record from database
  // 2. Read backup file
  // 3. Parse JSON data
  // 4. Clear current data (optionally)
  // 5. Import data from backup
  
  // This is stubbed for now
  return {
    success: false,
    error: 'Restore functionality not implemented yet'
  };
}
