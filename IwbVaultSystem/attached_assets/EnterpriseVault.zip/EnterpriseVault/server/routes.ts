import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { generateResponse, updateQueryResponses } from "./natural-language";
import { backupData, getBackups } from "./backup";
import { z } from "zod";
import { insertCustomerQuerySchema, insertProductSchema, insertProductCategorySchema, insertSaleSchema, insertFinanceRecordSchema } from "@shared/schema";

// Helper function to check role authorization
const authorizeRoles = (roles: string[]) => {
  return (req: Request, res: Response, next: Function) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    const userRole = (req.user as any).role;
    if (!roles.includes(userRole)) {
      return res.status(403).json({ message: "Forbidden: Insufficient permissions" });
    }
    
    next();
  };
};

// Helper to check tenant authorization
const authorizeTenant = (req: Request, res: Response, next: Function) => {
  if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
  
  const userTenantId = (req.user as any).tenantId;
  const requestedTenantId = parseInt(req.query.tenantId as string) || 1;
  
  // IWC (partner) can only access their own tenant
  if (userTenantId === 2 && requestedTenantId !== 2) {
    return res.status(403).json({ message: "Forbidden: Cannot access other tenant data" });
  }
  
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);
  
  // Customer Query Routes - accessible by anyone
  app.post("/api/queries", async (req, res) => {
    try {
      const queryData = insertCustomerQuerySchema.parse(req.body);
      const newQuery = await storage.createCustomerQuery(queryData);
      
      // Generate automated response based on similar queries
      const autoResponse = await generateResponse(queryData.message);
      
      if (autoResponse) {
        await storage.updateCustomerQuery(newQuery.id, {
          status: "auto-replied",
          autoReplyContent: autoResponse
        });
        
        // Update the query responses database
        await updateQueryResponses(queryData.message, autoResponse);
        
        newQuery.status = "auto-replied";
        newQuery.autoReplyContent = autoResponse;
      }
      
      res.status(201).json(newQuery);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid query data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to submit query" });
    }
  });
  
  // Product Routes - protected for sales, finance, developers
  app.get("/api/products", authorizeTenant, authorizeRoles(["sales", "finance", "developer"]), async (req, res) => {
    try {
      const tenantId = parseInt(req.query.tenantId as string) || (req.user as any).tenantId;
      const products = await storage.getAllProducts(tenantId);
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });
  
  app.post("/api/products", authorizeTenant, authorizeRoles(["sales", "developer"]), async (req, res) => {
    try {
      const productData = insertProductSchema.parse(req.body);
      const newProduct = await storage.createProduct({
        ...productData,
        tenantId: (req.user as any).tenantId
      });
      res.status(201).json(newProduct);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid product data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create product" });
    }
  });
  
  // Product Categories Routes
  app.get("/api/product-categories", authorizeTenant, authorizeRoles(["sales", "finance", "developer"]), async (req, res) => {
    try {
      const tenantId = parseInt(req.query.tenantId as string) || (req.user as any).tenantId;
      const categories = await storage.getAllProductCategories(tenantId);
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product categories" });
    }
  });
  
  app.post("/api/product-categories", authorizeTenant, authorizeRoles(["sales", "developer"]), async (req, res) => {
    try {
      const categoryData = insertProductCategorySchema.parse(req.body);
      const newCategory = await storage.createProductCategory({
        ...categoryData,
        tenantId: (req.user as any).tenantId
      });
      res.status(201).json(newCategory);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid category data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create category" });
    }
  });
  
  // Sales Routes - protected for sales, finance, developers
  app.get("/api/sales", authorizeTenant, authorizeRoles(["sales", "finance", "developer"]), async (req, res) => {
    try {
      const tenantId = parseInt(req.query.tenantId as string) || (req.user as any).tenantId;
      const sales = await storage.getAllSales(tenantId);
      res.json(sales);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sales records" });
    }
  });
  
  app.post("/api/sales", authorizeTenant, authorizeRoles(["sales", "developer"]), async (req, res) => {
    try {
      const saleData = insertSaleSchema.parse(req.body);
      
      // Set sales person ID to current user if not specified
      if (!saleData.salesPersonId) {
        saleData.salesPersonId = (req.user as any).id;
      }
      
      const newSale = await storage.createSale({
        ...saleData,
        tenantId: (req.user as any).tenantId
      });
      
      // Update product quantity
      const product = await storage.getProduct(saleData.productId);
      if (product) {
        await storage.updateProduct(product.id, {
          quantity: product.quantity - saleData.quantity
        });
      }
      
      res.status(201).json(newSale);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid sale data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create sale record" });
    }
  });
  
  // Finance Routes - protected for finance, developers
  app.get("/api/finance", authorizeTenant, authorizeRoles(["finance", "developer"]), async (req, res) => {
    try {
      const tenantId = parseInt(req.query.tenantId as string) || (req.user as any).tenantId;
      const records = await storage.getAllFinanceRecords(tenantId);
      res.json(records);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch finance records" });
    }
  });
  
  app.post("/api/finance", authorizeTenant, authorizeRoles(["finance", "developer"]), async (req, res) => {
    try {
      const financeData = insertFinanceRecordSchema.parse(req.body);
      
      // Set recorded by ID to current user if not specified
      if (!financeData.recordedById) {
        financeData.recordedById = (req.user as any).id;
      }
      
      const newRecord = await storage.createFinanceRecord({
        ...financeData,
        tenantId: (req.user as any).tenantId
      });
      
      res.status(201).json(newRecord);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid finance data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create finance record" });
    }
  });
  
  // Income Statements - protected for finance, developers, investors
  app.get("/api/income-statements", authorizeTenant, authorizeRoles(["finance", "developer", "investor"]), async (req, res) => {
    try {
      const tenantId = parseInt(req.query.tenantId as string) || (req.user as any).tenantId;
      const statements = await storage.getAllIncomeStatements(tenantId);
      res.json(statements);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch income statements" });
    }
  });
  
  app.get("/api/income-statements/generate", authorizeTenant, authorizeRoles(["finance", "developer"]), async (req, res) => {
    try {
      const tenantId = (req.user as any).tenantId;
      const month = parseInt(req.query.month as string) || new Date().getMonth() + 1;
      const year = parseInt(req.query.year as string) || new Date().getFullYear();
      
      // Generate income statement
      const incomeRecords = await storage.getFinanceRecordsByType("income", month, year, tenantId);
      const expenseRecords = await storage.getFinanceRecordsByType("expense", month, year, tenantId);
      
      const totalRevenue = incomeRecords.reduce((sum, record) => sum + record.amount, 0);
      const totalExpenses = expenseRecords.reduce((sum, record) => sum + record.amount, 0);
      const netIncome = totalRevenue - totalExpenses;
      
      const details = {
        income: incomeRecords,
        expenses: expenseRecords
      };
      
      const statement = await storage.createIncomeStatement({
        month,
        year,
        totalRevenue,
        totalExpenses,
        netIncome,
        details,
        generatedById: (req.user as any).id,
        tenantId
      });
      
      res.status(201).json(statement);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate income statement" });
    }
  });
  
  // Customer Queries Routes - protected for sales personnel
  app.get("/api/sales-queries", authorizeTenant, authorizeRoles(["sales", "developer"]), async (req, res) => {
    try {
      const tenantId = parseInt(req.query.tenantId as string) || (req.user as any).tenantId;
      const queries = await storage.getAllCustomerQueries(tenantId);
      res.json(queries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer queries" });
    }
  });
  
  app.put("/api/queries/:id", authorizeTenant, authorizeRoles(["sales", "developer"]), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status, responseContent } = req.body;
      
      const query = await storage.getCustomerQuery(id);
      if (!query) {
        return res.status(404).json({ message: "Customer query not found" });
      }
      
      // Only update if tenant matches
      if (query.tenantId !== (req.user as any).tenantId) {
        return res.status(403).json({ message: "Forbidden: Cannot access other tenant data" });
      }
      
      const updatedQuery = await storage.updateCustomerQuery(id, {
        status,
        responseContent,
        assignedToId: (req.user as any).id
      });
      
      res.json(updatedQuery);
    } catch (error) {
      res.status(500).json({ message: "Failed to update query" });
    }
  });
  
  // Backup Routes - protected for developers
  app.post("/api/backups", authorizeRoles(["developer"]), async (req, res) => {
    try {
      const result = await backupData((req.user as any).id);
      res.status(201).json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to create backup" });
    }
  });
  
  app.get("/api/backups", authorizeRoles(["developer"]), async (req, res) => {
    try {
      const backups = await getBackups();
      res.json(backups);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch backups" });
    }
  });
  
  // User Management Routes - protected for developers
  app.get("/api/users", authorizeRoles(["developer"]), async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users.map(user => ({ ...user, password: undefined }))); // Remove password from response
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  app.put("/api/users/:id/role", authorizeRoles(["developer"]), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { role } = req.body;
      
      if (!["sales", "finance", "developer", "investor", "client", "partner"].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }
      
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const updatedUser = await storage.updateUser(id, { role });
      res.json({ ...updatedUser, password: undefined });
    } catch (error) {
      res.status(500).json({ message: "Failed to update user role" });
    }
  });
  
  // Dashboard Stats - accessible to authenticated users
  app.get("/api/dashboard-stats", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const tenantId = (req.user as any).tenantId;
      const role = (req.user as any).role;
      
      // Basic stats for all roles
      const products = await storage.getAllProducts(tenantId);
      const queries = await storage.getAllCustomerQueries(tenantId);
      const pendingQueries = queries.filter(q => q.status === "pending").length;
      
      // Role-specific stats
      let stats: any = {
        totalProducts: products.length,
        pendingQueries
      };
      
      if (["sales", "finance", "developer", "investor"].includes(role)) {
        const sales = await storage.getAllSales(tenantId);
        const totalSales = sales.reduce((sum, sale) => sum + sale.totalAmount, 0);
        const recycledComponents = sales.reduce((sum, sale) => sum + sale.quantity, 0);
        
        stats = {
          ...stats,
          totalSales,
          recycledComponents,
          salesCount: sales.length
        };
      }
      
      if (["finance", "developer", "investor"].includes(role)) {
        const financeRecords = await storage.getAllFinanceRecords(tenantId);
        const income = financeRecords.filter(r => r.type === "income").reduce((sum, r) => sum + r.amount, 0);
        const expenses = financeRecords.filter(r => r.type === "expense").reduce((sum, r) => sum + r.amount, 0);
        const netIncome = income - expenses;
        
        stats = {
          ...stats,
          income,
          expenses,
          netIncome
        };
      }
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);
  return httpServer;
}
