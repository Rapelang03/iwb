import { pgTable, text, serial, integer, boolean, timestamp, jsonb, real, foreignKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User and auth schemas
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull().default("client"), // roles: sales, finance, developer, investor, client, partner
  createdAt: timestamp("created_at").defaultNow(),
  mfaSecret: text("mfa_secret"),
  mfaEnabled: boolean("mfa_enabled").default(false),
  phoneNumber: text("phone_number"),
  backupEmail: text("backup_email"),
  recoveryCode: text("recovery_code"),
  tenantId: integer("tenant_id").default(1), // 1: IWB (default), 2: IWC (partner)
});

export const insertUserSchema = createInsertSchema(users).omit({ 
  id: true, 
  createdAt: true, 
  mfaEnabled: true, 
  mfaSecret: true,
  recoveryCode: true
});

// Product and inventory schemas
export const productCategories = pgTable("product_categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  tenantId: integer("tenant_id").default(1),
});

export const insertProductCategorySchema = createInsertSchema(productCategories).omit({ 
  id: true,
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  serialNumber: text("serial_number"),
  categoryId: integer("category_id").notNull(),
  price: real("price").notNull(),
  quantity: integer("quantity").notNull().default(0),
  status: text("status").notNull().default("active"), // active, archived, sold
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  tenantId: integer("tenant_id").default(1),
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Sales records
export const sales = pgTable("sales", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  customerId: integer("customer_id"),
  quantity: integer("quantity").notNull().default(1),
  totalAmount: real("total_amount").notNull(),
  date: timestamp("date").defaultNow(),
  salesPersonId: integer("sales_person_id"),
  notes: text("notes"),
  receiptNumber: text("receipt_number"),
  tenantId: integer("tenant_id").default(1),
});

export const insertSaleSchema = createInsertSchema(sales).omit({
  id: true,
  date: true,
});

// Customer queries
export const customerQueries = pgTable("customer_queries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  status: text("status").notNull().default("pending"), // pending, auto-replied, completed
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  assignedToId: integer("assigned_to_id"),
  autoReplyContent: text("auto_reply_content"),
  responseContent: text("response_content"),
  tenantId: integer("tenant_id").default(1),
});

export const insertCustomerQuerySchema = createInsertSchema(customerQueries).omit({
  id: true,
  status: true,
  createdAt: true,
  updatedAt: true,
  assignedToId: true,
  autoReplyContent: true,
  responseContent: true,
});

// Finance records
export const financeRecords = pgTable("finance_records", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // income, expense
  category: text("category").notNull(), // sales, salary, rent, utilities, etc.
  amount: real("amount").notNull(),
  description: text("description"),
  date: timestamp("date").defaultNow(),
  recordedById: integer("recorded_by_id"),
  receiptNumber: text("receipt_number"),
  tenantId: integer("tenant_id").default(1),
});

export const insertFinanceRecordSchema = createInsertSchema(financeRecords).omit({
  id: true,
  date: true,
});

// Monthly income statements
export const incomeStatements = pgTable("income_statements", {
  id: serial("id").primaryKey(),
  month: integer("month").notNull(),
  year: integer("year").notNull(),
  totalRevenue: real("total_revenue").notNull(),
  totalExpenses: real("total_expenses").notNull(),
  netIncome: real("net_income").notNull(),
  details: jsonb("details"),
  generatedById: integer("generated_by_id"),
  generatedAt: timestamp("generated_at").defaultNow(),
  tenantId: integer("tenant_id").default(1),
});

export const insertIncomeStatementSchema = createInsertSchema(incomeStatements).omit({
  id: true,
  generatedAt: true,
});

// Query history for auto-replies
export const queryResponses = pgTable("query_responses", {
  id: serial("id").primaryKey(),
  query: text("query").notNull(),
  response: text("response").notNull(),
  frequency: integer("frequency").default(1),
  lastUsed: timestamp("last_used").defaultNow(),
  tenantId: integer("tenant_id").default(1),
});

export const insertQueryResponseSchema = createInsertSchema(queryResponses).omit({
  id: true,
  frequency: true,
  lastUsed: true,
});

// Activity logs
export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  action: text("action").notNull(),
  details: jsonb("details"),
  timestamp: timestamp("timestamp").defaultNow(),
  ip: text("ip"),
  userAgent: text("user_agent"),
  tenantId: integer("tenant_id").default(1),
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  timestamp: true,
});

// System backups
export const backups = pgTable("backups", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  size: integer("size").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  createdById: integer("created_by_id"),
  status: text("status").notNull().default("completed"), // pending, completed, failed
  backupType: text("backup_type").notNull(), // full, incremental, differential
  location: text("location").notNull(), // s3://bucket/path, local://path, etc.
  tenantId: integer("tenant_id").default(1),
});

export const insertBackupSchema = createInsertSchema(backups).omit({
  id: true,
  createdAt: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type ProductCategory = typeof productCategories.$inferSelect;
export type InsertProductCategory = z.infer<typeof insertProductCategorySchema>;

export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type Sale = typeof sales.$inferSelect;
export type InsertSale = z.infer<typeof insertSaleSchema>;

export type CustomerQuery = typeof customerQueries.$inferSelect;
export type InsertCustomerQuery = z.infer<typeof insertCustomerQuerySchema>;

export type FinanceRecord = typeof financeRecords.$inferSelect;
export type InsertFinanceRecord = z.infer<typeof insertFinanceRecordSchema>;

export type IncomeStatement = typeof incomeStatements.$inferSelect;
export type InsertIncomeStatement = z.infer<typeof insertIncomeStatementSchema>;

export type QueryResponse = typeof queryResponses.$inferSelect;
export type InsertQueryResponse = z.infer<typeof insertQueryResponseSchema>;

export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;

export type Backup = typeof backups.$inferSelect;
export type InsertBackup = z.infer<typeof insertBackupSchema>;
