import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Sidebar from "@/components/dashboard/sidebar";
import Header from "@/components/dashboard/header";
import ChartCard from "@/components/dashboard/chart-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertFinanceRecordSchema } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { 
  PlusCircle, 
  Download, 
  TrendingUp, 
  TrendingDown,
  DollarSign,
  ArrowRight,
  FileText,
  Loader2
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from "recharts";

// Extend the finance record schema for form validation
const financeFormSchema = z.object({
  type: z.enum(["income", "expense"]),
  category: z.string().min(1, "Category is required"),
  amount: z.number().min(0.01, "Amount must be greater than 0"),
  description: z.string().optional(),
  receiptNumber: z.string().optional(),
});

export default function FinancePage() {
  const { user } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const [isNewFinanceRecordOpen, setIsNewFinanceRecordOpen] = useState(false);
  const [isGeneratingStatement, setIsGeneratingStatement] = useState(false);
  
  // Fetch finance records
  const { data: financeRecords, isLoading: isLoadingRecords } = useQuery({
    queryKey: ['/api/finance'],
  });
  
  // Fetch income statements
  const { data: incomeStatements, isLoading: isLoadingStatements } = useQuery({
    queryKey: ['/api/income-statements'],
  });
  
  // Finance record mutation
  const createFinanceRecordMutation = useMutation({
    mutationFn: async (record: z.infer<typeof financeFormSchema>) => {
      const res = await apiRequest("POST", "/api/finance", record);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/finance'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard-stats'] });
      setIsNewFinanceRecordOpen(false);
      form.reset();
    },
  });
  
  // Generate income statement mutation
  const generateStatementMutation = useMutation({
    mutationFn: async ({ month, year }: { month: number, year: number }) => {
      const res = await apiRequest("GET", `/api/income-statements/generate?month=${month}&year=${year}`, null);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/income-statements'] });
      setIsGeneratingStatement(false);
    },
  });
  
  // Form setup
  const form = useForm<z.infer<typeof financeFormSchema>>({
    resolver: zodResolver(financeFormSchema),
    defaultValues: {
      type: "income",
      category: "",
      amount: 0,
      description: "",
      receiptNumber: `FIN-${Date.now().toString().slice(-6)}`,
    },
  });
  
  // Handle form submission
  const onSubmit = (values: z.infer<typeof financeFormSchema>) => {
    createFinanceRecordMutation.mutate(values);
  };
  
  // Generate a new monthly income statement
  const generateMonthlyStatement = () => {
    setIsGeneratingStatement(true);
    const now = new Date();
    generateStatementMutation.mutate({ 
      month: now.getMonth() + 1, 
      year: now.getFullYear() 
    });
  };
  
  // Prepare data for charts
  const prepareChartData = () => {
    if (!financeRecords) return { monthlyData: [], categoryData: [] };
    
    // Group by month for monthly overview
    const months: Record<string, { income: number, expense: number }> = {};
    
    // Group by category for expense breakdown
    const categories: Record<string, number> = {};
    
    financeRecords.forEach(record => {
      // Format date to YYYY-MM
      const date = new Date(record.date);
      const monthKey = format(date, 'MMM yyyy');
      
      // Add to monthly data
      if (!months[monthKey]) {
        months[monthKey] = { income: 0, expense: 0 };
      }
      if (record.type === 'income') {
        months[monthKey].income += record.amount;
      } else {
        months[monthKey].expense += record.amount;
      }
      
      // Add to category data (for expenses only)
      if (record.type === 'expense') {
        if (!categories[record.category]) {
          categories[record.category] = 0;
        }
        categories[record.category] += record.amount;
      }
    });
    
    // Convert to array format for charts
    const monthlyData = Object.entries(months).map(([month, data]) => ({
      month,
      income: data.income,
      expense: data.expense,
      profit: data.income - data.expense,
    }));
    
    // Sort monthly data by date
    monthlyData.sort((a, b) => {
      const dateA = new Date(a.month);
      const dateB = new Date(b.month);
      return dateA.getTime() - dateB.getTime();
    });
    
    const categoryData = Object.entries(categories).map(([name, value]) => ({
      name,
      value,
    }));
    
    // Sort category data by value (descending)
    categoryData.sort((a, b) => b.value - a.value);
    
    return { monthlyData, categoryData };
  };
  
  const { monthlyData, categoryData } = prepareChartData();
  
  // Total calculations
  const totalIncome = financeRecords
    ? financeRecords.filter(r => r.type === 'income').reduce((sum, r) => sum + r.amount, 0)
    : 0;
    
  const totalExpenses = financeRecords
    ? financeRecords.filter(r => r.type === 'expense').reduce((sum, r) => sum + r.amount, 0)
    : 0;
    
  const netProfit = totalIncome - totalExpenses;
  
  // Colors for pie chart
  const COLORS = ['#4CAF50', '#2196F3', '#FF9800', '#E91E63', '#9C27B0'];
  
  return (
    <div className="h-screen flex overflow-hidden">
      {/* Sidebar */}
      <Sidebar 
        mobileMenuOpen={mobileMenuOpen} 
        setMobileMenuOpen={setMobileMenuOpen} 
        currentPath="/finance"
      />
      
      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden bg-gradient-to-br from-dark-900 to-dark-800">
        {/* Top Header */}
        <Header 
          toggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)} 
          title="Finance Management" 
        />
        
        {/* Finance Page Content */}
        <div className="flex-1 overflow-y-auto px-4 md:px-6 py-6">
          {/* Page Title & Action Buttons */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
            <div className="mb-4 md:mb-0">
              <h1 className="text-2xl md:text-3xl font-heading font-bold text-white">Financial Overview</h1>
              <p className="text-muted-foreground mt-1">
                Track and manage your company's financial performance
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2">
              <Button variant="outline" className="sm:order-1">
                <Download className="mr-2 h-4 w-4" />
                Export Report
              </Button>
              <Button onClick={() => setIsNewFinanceRecordOpen(true)}>
                <PlusCircle className="mr-2 h-4 w-4" />
                New Record
              </Button>
            </div>
          </div>
          
          {/* Financial Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card className="glass border-none">
              <CardContent className="p-5 flex items-center">
                <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center text-primary mr-4">
                  <TrendingUp className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-muted-foreground text-sm">Total Revenue</p>
                  <h3 className="text-white text-2xl font-semibold">M {totalIncome.toLocaleString()}</h3>
                </div>
              </CardContent>
            </Card>
            
            <Card className="glass border-none">
              <CardContent className="p-5 flex items-center">
                <div className="h-12 w-12 rounded-full bg-accent/20 flex items-center justify-center text-accent mr-4">
                  <TrendingDown className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-muted-foreground text-sm">Total Expenses</p>
                  <h3 className="text-white text-2xl font-semibold">M {totalExpenses.toLocaleString()}</h3>
                </div>
              </CardContent>
            </Card>
            
            <Card className="glass border-none">
              <CardContent className="p-5 flex items-center">
                <div className="h-12 w-12 rounded-full bg-secondary-500/20 flex items-center justify-center text-secondary-500 mr-4">
                  <DollarSign className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-muted-foreground text-sm">Net Profit</p>
                  <h3 className="text-white text-2xl font-semibold">M {netProfit.toLocaleString()}</h3>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Tabs for different views */}
          <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="grid w-full md:w-[400px] grid-cols-3">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="records">Records</TabsTrigger>
              <TabsTrigger value="statements">Statements</TabsTrigger>
            </TabsList>
            
            {/* Overview Tab Content */}
            <TabsContent value="overview">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                {/* Monthly Revenue & Expense Chart */}
                <ChartCard title="Monthly Financial Overview">
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart
                      data={monthlyData}
                      margin={{ top: 20, right: 30, left: 0, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--muted))" />
                      <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" />
                      <YAxis stroke="hsl(var(--muted-foreground))" />
                      <Tooltip
                        formatter={(value: number) => [`M ${value.toLocaleString()}`, '']}
                        contentStyle={{
                          backgroundColor: 'hsl(var(--card))',
                          borderColor: 'hsl(var(--border))',
                          color: 'hsl(var(--card-foreground))'
                        }}
                      />
                      <Legend />
                      <Bar dataKey="income" name="Income" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="expense" name="Expense" fill="hsl(var(--accent))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartCard>
                
                {/* Profit Trend Chart */}
                <ChartCard title="Profit Trend">
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart
                      data={monthlyData}
                      margin={{ top: 20, right: 30, left: 0, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--muted))" />
                      <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" />
                      <YAxis stroke="hsl(var(--muted-foreground))" />
                      <Tooltip
                        formatter={(value: number) => [`M ${value.toLocaleString()}`, 'Profit']}
                        contentStyle={{
                          backgroundColor: 'hsl(var(--card))',
                          borderColor: 'hsl(var(--border))',
                          color: 'hsl(var(--card-foreground))'
                        }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="profit" 
                        name="Net Profit" 
                        stroke="hsl(var(--secondary-500))" 
                        strokeWidth={2}
                        dot={{ fill: 'hsl(var(--secondary-500))' }}
                        activeDot={{ r: 8 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </ChartCard>
              </div>
              
              {/* Expense Breakdown */}
              <Card className="glass border-none mb-6">
                <CardHeader className="pb-3">
                  <CardTitle className="text-white font-semibold">Expense Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex justify-center items-center h-[300px]">
                      <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                          <Pie
                            data={categoryData}
                            innerRadius={60}
                            outerRadius={90}
                            paddingAngle={5}
                            dataKey="value"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {categoryData.map((entry, index) => (
                              <Cell 
                                key={`cell-${index}`} 
                                fill={COLORS[index % COLORS.length]} 
                              />
                            ))}
                          </Pie>
                          <Tooltip
                            formatter={(value: number) => [`M ${value.toLocaleString()}`, 'Amount']}
                            contentStyle={{
                              backgroundColor: 'hsl(var(--card))',
                              borderColor: 'hsl(var(--border))',
                              color: 'hsl(var(--card-foreground))'
                            }}
                          />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    
                    <div className="flex flex-col justify-center">
                      <h4 className="text-white font-medium mb-4">Top Expense Categories</h4>
                      <div className="space-y-3">
                        {categoryData.slice(0, 5).map((category, index) => (
                          <div key={index} className="flex items-center">
                            <div 
                              className="w-3 h-3 rounded-full mr-2" 
                              style={{ backgroundColor: COLORS[index % COLORS.length] }}
                            ></div>
                            <span className="text-muted-foreground flex-1">{category.name}</span>
                            <span className="text-white font-medium">
                              M {category.value.toLocaleString()}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Records Tab Content */}
            <TabsContent value="records">
              <Card className="glass border-none">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-center flex-wrap gap-3">
                    <CardTitle className="text-white font-semibold">Finance Records</CardTitle>
                    <Button 
                      size="sm" 
                      onClick={() => setIsNewFinanceRecordOpen(true)}
                    >
                      <PlusCircle className="mr-2 h-4 w-4" />
                      New Record
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Description</TableHead>
                          <TableHead>Category</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Receipt #</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {isLoadingRecords ? (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center py-8">
                              <Loader2 className="h-6 w-6 animate-spin mx-auto text-muted-foreground" />
                            </TableCell>
                          </TableRow>
                        ) : financeRecords?.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                              No financial records found.
                            </TableCell>
                          </TableRow>
                        ) : (
                          financeRecords?.map((record) => (
                            <TableRow key={record.id}>
                              <TableCell className="font-medium text-white">{record.description || '-'}</TableCell>
                              <TableCell>{record.category}</TableCell>
                              <TableCell>
                                <Badge variant="outline" className={record.type === 'income' ? 'bg-primary/20 text-primary' : 'bg-accent/20 text-accent'}>
                                  {record.type === 'income' ? 'Income' : 'Expense'}
                                </Badge>
                              </TableCell>
                              <TableCell>M {record.amount.toLocaleString()}</TableCell>
                              <TableCell>{format(new Date(record.date), 'MMM dd, yyyy')}</TableCell>
                              <TableCell>{record.receiptNumber || '-'}</TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Income Statements Tab Content */}
            <TabsContent value="statements">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-white">Monthly Income Statements</h2>
                <Button 
                  onClick={generateMonthlyStatement}
                  disabled={generateStatementMutation.isPending}
                >
                  {generateStatementMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  Generate Current Month
                </Button>
              </div>
              
              <Card className="glass border-none">
                <CardContent className="p-0">
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Period</TableHead>
                          <TableHead>Revenue</TableHead>
                          <TableHead>Expenses</TableHead>
                          <TableHead>Net Income</TableHead>
                          <TableHead>Generated On</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {isLoadingStatements ? (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center py-8">
                              <Loader2 className="h-6 w-6 animate-spin mx-auto text-muted-foreground" />
                            </TableCell>
                          </TableRow>
                        ) : incomeStatements?.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                              No income statements found. Click "Generate Current Month" to create one.
                            </TableCell>
                          </TableRow>
                        ) : (
                          incomeStatements?.map((statement) => (
                            <TableRow key={statement.id}>
                              <TableCell className="font-medium text-white">
                                {new Date(statement.year, statement.month - 1).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                              </TableCell>
                              <TableCell className="text-primary">
                                M {statement.totalRevenue.toLocaleString()}
                              </TableCell>
                              <TableCell className="text-accent">
                                M {statement.totalExpenses.toLocaleString()}
                              </TableCell>
                              <TableCell className={statement.netIncome >= 0 ? 'text-primary' : 'text-accent'}>
                                M {statement.netIncome.toLocaleString()}
                              </TableCell>
                              <TableCell>
                                {format(new Date(statement.generatedAt), 'MMM dd, yyyy')}
                              </TableCell>
                              <TableCell>
                                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                  <FileText className="h-4 w-4" />
                                  <span className="sr-only">View</span>
                                </Button>
                                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                  <Download className="h-4 w-4" />
                                  <span className="sr-only">Download</span>
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      {/* New Finance Record Dialog */}
      <Dialog open={isNewFinanceRecordOpen} onOpenChange={setIsNewFinanceRecordOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Add Financial Record</DialogTitle>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Type</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="income">Income</SelectItem>
                        <SelectItem value="expense">Expense</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {form.watch("type") === "income" ? (
                            <>
                              <SelectItem value="sales">Sales</SelectItem>
                              <SelectItem value="investment">Investment</SelectItem>
                              <SelectItem value="refund">Refund</SelectItem>
                              <SelectItem value="other_income">Other Income</SelectItem>
                            </>
                          ) : (
                            <>
                              <SelectItem value="salary">Salary & Wages</SelectItem>
                              <SelectItem value="rent">Rent & Utilities</SelectItem>
                              <SelectItem value="equipment">Equipment & Supplies</SelectItem>
                              <SelectItem value="transportation">Transportation</SelectItem>
                              <SelectItem value="marketing">Marketing & Advertising</SelectItem>
                              <SelectItem value="other_expense">Other Expense</SelectItem>
                            </>
                          )}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Amount</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute left-3 top-2.5">M</span>
                          <Input
                            type="number"
                            step="0.01"
                            className="pl-8"
                            value={field.value}
                            onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description (Optional)</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="receiptNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Receipt Number (Optional)</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  variant="outline" 
                  type="button" 
                  onClick={() => setIsNewFinanceRecordOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={createFinanceRecordMutation.isPending}
                >
                  {createFinanceRecordMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  Save Record
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
