import { useState, useEffect } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";
import { useMFA } from "@/hooks/use-mfa";
import { useLocation } from "wouter";
import { insertUserSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RecycleIcon, ShieldCheck, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
  rememberMe: z.boolean().optional(),
});

const registerSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(6, "Password must be at least 6 characters"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export default function AuthPage() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const showMfa = false;
  
  const { 
    user, 
    loginMutation, 
    registerMutation, 
    requiresMFA 
  } = useAuth();
  
  const {
    mfaCode,
    handleCodeChange,
    handleKeyDown,
    verifyMFA,
    isPending: mfaIsPending
  } = useMFA();
  
  const [authTab, setAuthTab] = useState<string>("login");
  
  // Redirect if already logged in and MFA is not required
  useEffect(() => {
    if (user && !requiresMFA) {
      setLocation("/");
    }
  }, [user, requiresMFA, setLocation]);
  
  // Login form
  const loginForm = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
      rememberMe: false,
    },
  });
  
  // Register form
  const registerForm = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
      fullName: "",
      role: "client",
    },
  });
  
  // Handle login submission
  const onLoginSubmit = (values: z.infer<typeof loginSchema>) => {
    loginMutation.mutate({
      username: values.username,
      password: values.password,
    });
  };
  
  // Handle register submission
  const onRegisterSubmit = (values: z.infer<typeof registerSchema>) => {
    // Remove confirmPassword as it's not in the schema
    const { confirmPassword, ...userData } = values;
    registerMutation.mutate(userData);
  };
  
  // Handle MFA submission
  const handleMfaSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = await verifyMFA();
    
    if (!result.success && result.message) {
      toast({
        title: "MFA Verification Failed",
        description: result.message,
        variant: "destructive",
      });
    }
  };
  
  // Decorative elements for background
  const BackgroundDecorations = () => (
    <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-pulse"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-pulse delay-700"></div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-accent rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-pulse delay-1000"></div>
    </div>
  );
  
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-dark-900 to-dark-800">
      <BackgroundDecorations />
      
      <div className="w-full max-w-md z-10">
        {/* Logo and Brand */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center">
            <div className="w-12 h-12 rounded-lg bg-primary flex items-center justify-center shadow-lg">
              <RecycleIcon className="text-white text-2xl" />
            </div>
            <h1 className="ml-2 text-3xl font-bold text-white font-heading">IWB <span className="text-primary">Recycle</span></h1>
          </div>
        </div>
        
        {/* MFA Verification Form */}
        {(showMfa || requiresMFA) ? (
          <Card className="glass rounded-xl mb-8">
            <CardContent className="pt-6">
              <div className="text-center mb-6">
                <ShieldCheck className="h-16 w-16 text-primary mx-auto mb-2" />
                <h2 className="text-2xl font-bold text-white font-heading">Two-Factor Authentication</h2>
                <p className="text-muted-foreground mt-2">Enter the 6-digit code from your authenticator app</p>
              </div>
              
              <form onSubmit={handleMfaSubmit} className="space-y-6">
                <div className="flex justify-between space-x-2">
                  {[0, 1, 2, 3, 4, 5].map((index) => (
                    <input
                      key={index}
                      id={`mfa-input-${index}`}
                      type="text"
                      value={mfaCode[index]}
                      onChange={(e) => handleCodeChange(index, e.target.value)}
                      onKeyDown={(e) => handleKeyDown(index, e)}
                      maxLength={1}
                      className="w-12 h-14 text-center text-xl font-bold rounded-lg bg-dark-800 border border-dark-700 text-white focus:outline-none focus:ring-2 focus:ring-primary transition"
                      autoFocus={index === 0}
                    />
                  ))}
                </div>
                
                <Button type="submit" className="w-full" disabled={mfaIsPending}>
                  {mfaIsPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Verify
                </Button>
                
                <div className="text-center text-muted-foreground text-sm">
                  <p>Didn't receive a code? <Button variant="link" className="p-0 text-primary">Resend</Button></p>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          /* Authentication Forms */
          <Card className="glass rounded-xl mb-8">
            <CardContent className="pt-6">
              <Tabs defaultValue={authTab} onValueChange={setAuthTab} className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-6">
                  <TabsTrigger value="login">Sign In</TabsTrigger>
                  <TabsTrigger value="register">Register</TabsTrigger>
                </TabsList>
                
                <TabsContent value="login">
                  <Form {...loginForm}>
                    <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-5">
                      <FormField
                        control={loginForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Username or Email</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your username or email" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={loginForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="••••••••" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="flex items-center justify-between">
                        <FormField
                          control={loginForm.control}
                          name="rememberMe"
                          render={({ field }) => (
                            <div className="flex items-center space-x-2">
                              <Checkbox
                                id="remember-me"
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                              <label
                                htmlFor="remember-me"
                                className="text-sm text-muted-foreground cursor-pointer"
                              >
                                Remember me
                              </label>
                            </div>
                          )}
                        />
                        <Button variant="link" className="p-0 text-primary text-sm">
                          Forgot password?
                        </Button>
                      </div>
                      
                      <Button type="submit" className="w-full" disabled={loginMutation.isPending}>
                        {loginMutation.isPending && (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        )}
                        Sign in
                      </Button>
                    </form>
                  </Form>
                </TabsContent>
                
                <TabsContent value="register">
                  <Form {...registerForm}>
                    <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                      <FormField
                        control={registerForm.control}
                        name="fullName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your full name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={registerForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input type="email" placeholder="Enter your email" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={registerForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Username</FormLabel>
                            <FormControl>
                              <Input placeholder="Choose a username" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={registerForm.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Password</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="••••••••" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={registerForm.control}
                          name="confirmPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Confirm Password</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="••••••••" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <Button type="submit" className="w-full" disabled={registerMutation.isPending}>
                        {registerMutation.isPending && (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        )}
                        Create Account
                      </Button>
                    </form>
                  </Form>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        )}
        
        <div className="text-center text-muted-foreground text-sm">
          <p>© 2025 IWB Electronics Recycling. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}
