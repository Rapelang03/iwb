import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Sidebar from "@/components/dashboard/sidebar";
import Header from "@/components/dashboard/header";
import QueryModal from "@/components/query-modal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { Search, FileText, MessageSquareText, CheckCircle } from "lucide-react";

export default function QueriesPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [isQueryModalOpen, setIsQueryModalOpen] = useState(false);
  const [selectedQuery, setSelectedQuery] = useState<any>(null);
  
  // Fetch customer queries
  const { data: queries, isLoading } = useQuery({
    queryKey: ['/api/sales-queries'],
  });
  
  // Update query status mutation
  const updateQueryMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number, status: string }) => {
      const res = await apiRequest("PUT", `/api/queries/${id}`, {
        status
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sales-queries'] });
      toast({
        title: "Query status updated",
        description: "The query status has been successfully updated.",
      });
    },
  });
  
  // Filter queries based on active tab and search term
  const filteredQueries = queries?.filter(query => {
    // Filter by tab
    if (activeTab !== "all" && query.status !== activeTab) {
      return false;
    }
    
    // Filter by search term
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      return (
        query.name.toLowerCase().includes(search) ||
        query.email.toLowerCase().includes(search) ||
        query.subject.toLowerCase().includes(search) ||
        query.message.toLowerCase().includes(search)
      );
    }
    
    return true;
  });
  
  // Open reply modal
  const handleReply = (query: any) => {
    setSelectedQuery(query);
    setIsQueryModalOpen(true);
  };
  
  // Mark query as complete
  const markAsComplete = (id: number) => {
    updateQueryMutation.mutate({ id, status: "completed" });
  };
  
  // Format status text
  const formatStatus = (status: string) => {
    switch (status) {
      case "pending":
        return "Pending";
      case "auto-replied":
        return "Auto-Replied";
      case "completed":
        return "Completed";
      default:
        return status;
    }
  };
  
  // Get status badge color
  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-accent/20 text-accent";
      case "auto-replied":
        return "bg-secondary-500/20 text-secondary-500";
      case "completed":
        return "bg-primary/20 text-primary";
      default:
        return "bg-muted text-muted-foreground";
    }
  };
  
  // Get initials from name
  const getInitials = (name: string) => {
    const names = name.split(' ');
    if (names.length === 1) return names[0].substring(0, 1).toUpperCase();
    return (names[0][0] + names[names.length - 1][0]).toUpperCase();
  };
  
  // Get time passed since query was created
  const getTimeAgo = (dateString: string) => {
    return formatDistanceToNow(new Date(dateString), { addSuffix: true });
  };
  
  return (
    <div className="h-screen flex overflow-hidden">
      {/* Sidebar */}
      <Sidebar 
        mobileMenuOpen={mobileMenuOpen} 
        setMobileMenuOpen={setMobileMenuOpen} 
        currentPath="/queries"
      />
      
      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden bg-gradient-to-br from-dark-900 to-dark-800">
        {/* Top Header */}
        <Header 
          toggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)} 
          title="Customer Queries" 
        />
        
        {/* Queries Page Content */}
        <div className="flex-1 overflow-y-auto px-4 md:px-6 py-6">
          {/* Page Title & Action Buttons */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
            <div className="mb-4 md:mb-0">
              <h1 className="text-2xl md:text-3xl font-heading font-bold text-white">Customer Queries</h1>
              <p className="text-muted-foreground mt-1">
                Manage and respond to customer inquiries
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search queries..."
                  className="pl-8 w-full sm:w-[200px] lg:w-[300px]"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <Button variant="outline">
                <FileText className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
          
          {/* Queries Tabs */}
          <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="grid w-full md:w-[400px] grid-cols-3">
              <TabsTrigger value="all">All Queries</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="completed">Completed</TabsTrigger>
            </TabsList>
            
            <TabsContent value={activeTab}>
              <Card className="glass border-none">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-center flex-wrap gap-3">
                    <CardTitle className="text-white font-semibold">
                      {activeTab === "all" ? "All Queries" : 
                        activeTab === "pending" ? "Pending Queries" : "Completed Queries"}
                    </CardTitle>
                    {activeTab === "pending" && queries?.filter(q => q.status === "pending").length > 0 && (
                      <Badge variant="outline" className="bg-accent/20 text-accent">
                        {queries?.filter(q => q.status === "pending").length} pending
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="space-y-4">
                      <Skeleton className="h-24 w-full rounded-lg" />
                      <Skeleton className="h-24 w-full rounded-lg" />
                      <Skeleton className="h-24 w-full rounded-lg" />
                    </div>
                  ) : filteredQueries?.length === 0 ? (
                    <div className="text-center py-8">
                      <MessageSquareText className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                      <h3 className="text-lg font-medium text-white">No queries found</h3>
                      <p className="text-muted-foreground mt-1">
                        {activeTab === "all" 
                          ? "No customer queries have been submitted yet."
                          : activeTab === "pending" 
                            ? "There are no pending queries to address."
                            : "There are no completed queries."}
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {filteredQueries?.map((query) => (
                        <div key={query.id} className="rounded-lg bg-muted/20 p-4">
                          <div className="flex flex-col md:flex-row md:items-start">
                            <Avatar className="h-10 w-10 mb-2 md:mb-0">
                              <AvatarFallback className="bg-secondary-700 text-white">
                                {getInitials(query.name)}
                              </AvatarFallback>
                            </Avatar>
                            <div className="md:ml-3 flex-1">
                              <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                                <div>
                                  <h4 className="text-white font-medium">{query.name}</h4>
                                  <p className="text-muted-foreground text-sm">{query.email}</p>
                                </div>
                                <div className="flex items-center gap-2">
                                  <Badge variant="outline" className={getStatusColor(query.status)}>
                                    {formatStatus(query.status)}
                                  </Badge>
                                  <p className="text-muted-foreground text-xs">
                                    {getTimeAgo(query.createdAt)}
                                  </p>
                                </div>
                              </div>
                              
                              <div className="mt-3">
                                <h5 className="text-white font-medium">{query.subject}</h5>
                                <p className="text-muted-foreground mt-1">{query.message}</p>
                                
                                {query.autoReplyContent && (
                                  <div className="mt-3 p-3 rounded bg-muted/30 border-l-2 border-secondary-500">
                                    <p className="text-xs text-muted-foreground mb-1">Auto-Reply:</p>
                                    <p className="text-sm text-muted-foreground">{query.autoReplyContent}</p>
                                  </div>
                                )}
                                
                                {query.responseContent && (
                                  <div className="mt-3 p-3 rounded bg-muted/30 border-l-2 border-primary">
                                    <p className="text-xs text-muted-foreground mb-1">Your Response:</p>
                                    <p className="text-sm text-muted-foreground">{query.responseContent}</p>
                                  </div>
                                )}
                              </div>
                              
                              <div className="flex justify-end mt-3">
                                {query.status !== "completed" && (
                                  <>
                                    <Button 
                                      variant="outline" 
                                      size="sm" 
                                      className="mr-2"
                                      onClick={() => markAsComplete(query.id)}
                                    >
                                      <CheckCircle className="mr-2 h-4 w-4" />
                                      Mark Complete
                                    </Button>
                                    <Button 
                                      size="sm"
                                      onClick={() => handleReply(query)}
                                    >
                                      Reply
                                    </Button>
                                  </>
                                )}
                                
                                {query.status === "completed" && (
                                  <Button 
                                    variant="outline" 
                                    size="sm"
                                    onClick={() => handleReply(query)}
                                  >
                                    View Details
                                  </Button>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      {/* Query Reply Modal */}
      {selectedQuery && (
        <QueryModal 
          isOpen={isQueryModalOpen} 
          onClose={() => {
            setIsQueryModalOpen(false);
            setSelectedQuery(null);
          }}
          initialData={{
            id: selectedQuery.id,
            name: selectedQuery.name,
            email: selectedQuery.email,
            message: selectedQuery.message
          }}
          isReply={true}
        />
      )}
    </div>
  );
}
