import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Sidebar from "@/components/dashboard/sidebar";
import Header from "@/components/dashboard/header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Search, 
  PlusCircle, 
  UserPlus, 
  Edit, 
  Trash2, 
  User, 
  ShieldCheck, 
  Building, 
  LogOut, 
  KeyRound, 
  AlertCircle, 
  Loader2,
  CheckCircle,
  XCircle
} from "lucide-react";

// User invite form schema
const inviteUserSchema = z.object({
  email: z.string().email("Invalid email address"),
  fullName: z.string().min(3, "Full name must be at least 3 characters"),
  role: z.enum(["sales", "finance", "developer", "investor", "client", "partner"]),
  tenantId: z.number().int().positive(),
});

// User role update schema
const updateRoleSchema = z.object({
  role: z.enum(["sales", "finance", "developer", "investor", "client", "partner"]),
});

export default function UserManagementPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [isEditRoleModalOpen, setIsEditRoleModalOpen] = useState(false);
  
  // Fetch users
  const { data: users, isLoading } = useQuery({
    queryKey: ['/api/users'],
  });
  
  // Invite user mutation
  const inviteUserMutation = useMutation({
    mutationFn: async (data: z.infer<typeof inviteUserSchema>) => {
      const res = await apiRequest("POST", "/api/register", {
        ...data,
        username: data.email.split('@')[0], // Generate username from email
        password: `temp${Math.random().toString(36).substring(2, 10)}`, // Temporary password
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      setIsInviteModalOpen(false);
      inviteForm.reset();
      toast({
        title: "User invited",
        description: "An invitation has been sent to the user.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to invite user",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update user role mutation
  const updateRoleMutation = useMutation({
    mutationFn: async ({ id, role }: { id: number, role: string }) => {
      const res = await apiRequest("PUT", `/api/users/${id}/role`, { role });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      setIsEditRoleModalOpen(false);
      setSelectedUser(null);
      toast({
        title: "Role updated",
        description: "The user's role has been successfully updated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update role",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Invite form
  const inviteForm = useForm<z.infer<typeof inviteUserSchema>>({
    resolver: zodResolver(inviteUserSchema),
    defaultValues: {
      email: "",
      fullName: "",
      role: "client",
      tenantId: 1,
    },
  });
  
  // Role update form
  const roleForm = useForm<z.infer<typeof updateRoleSchema>>({
    resolver: zodResolver(updateRoleSchema),
    defaultValues: {
      role: "client",
    },
  });
  
  // Handle invite user form submission
  const onInviteSubmit = (values: z.infer<typeof inviteUserSchema>) => {
    inviteUserMutation.mutate(values);
  };
  
  // Handle role update form submission
  const onRoleUpdateSubmit = (values: z.infer<typeof updateRoleSchema>) => {
    if (!selectedUser) return;
    updateRoleMutation.mutate({ id: selectedUser.id, role: values.role });
  };
  
  // Open edit role modal
  const handleEditRole = (user: any) => {
    setSelectedUser(user);
    roleForm.setValue("role", user.role);
    setIsEditRoleModalOpen(true);
  };
  
  // Filter users based on active tab and search term
  const filteredUsers = users?.filter(u => {
    // Skip filtering for "all" tab
    if (activeTab !== "all" && u.role !== activeTab) {
      return false;
    }
    
    // Filter by search term
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      return (
        u.fullName.toLowerCase().includes(search) ||
        u.email.toLowerCase().includes(search) ||
        u.username.toLowerCase().includes(search) ||
        u.role.toLowerCase().includes(search)
      );
    }
    
    return true;
  });
  
  // Role display names
  const roleDisplay = (role: string) => {
    const roleMap: Record<string, string> = {
      sales: "Sales Personnel",
      finance: "Finance Personnel",
      developer: "Developer",
      investor: "Investor",
      client: "Client",
      partner: "Partner"
    };
    return roleMap[role] || role.charAt(0).toUpperCase() + role.slice(1);
  };
  
  // Get role badge color
  const getRoleBadgeColor = (role: string) => {
    const colorMap: Record<string, string> = {
      sales: "bg-secondary-500/20 text-secondary-500",
      finance: "bg-primary/20 text-primary",
      developer: "bg-indigo-500/20 text-indigo-400",
      investor: "bg-amber-500/20 text-amber-400",
      client: "bg-muted text-muted-foreground",
      partner: "bg-accent/20 text-accent"
    };
    return colorMap[role] || "bg-muted text-muted-foreground";
  };
  
  // Get user initials for avatar
  const getUserInitials = (name: string) => {
    if (!name) return "U";
    const nameParts = name.split(" ");
    if (nameParts.length === 1) return nameParts[0].charAt(0).toUpperCase();
    return (nameParts[0].charAt(0) + nameParts[nameParts.length - 1].charAt(0)).toUpperCase();
  };
  
  // Get tenant name
  const getTenantName = (tenantId: number) => {
    return tenantId === 1 ? "IWB" : tenantId === 2 ? "IWC" : "Unknown";
  };
  
  return (
    <div className="h-screen flex overflow-hidden">
      {/* Sidebar */}
      <Sidebar 
        mobileMenuOpen={mobileMenuOpen} 
        setMobileMenuOpen={setMobileMenuOpen} 
        currentPath="/users"
      />
      
      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden bg-gradient-to-br from-dark-900 to-dark-800">
        {/* Top Header */}
        <Header 
          toggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)} 
          title="User Management" 
        />
        
        {/* User Management Content */}
        <div className="flex-1 overflow-y-auto px-4 md:px-6 py-6">
          {/* Page Title & Action Buttons */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
            <div className="mb-4 md:mb-0">
              <h1 className="text-2xl md:text-3xl font-heading font-bold text-white">User Management</h1>
              <p className="text-muted-foreground mt-1">
                Manage users and their access permissions
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search users..."
                  className="pl-8 w-full sm:w-[200px] lg:w-[300px]"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <Button onClick={() => setIsInviteModalOpen(true)}>
                <UserPlus className="mr-2 h-4 w-4" />
                Invite User
              </Button>
            </div>
          </div>
          
          {/* User Tabs */}
          <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="grid grid-cols-3 md:grid-cols-7 md:w-auto">
              <TabsTrigger value="all">All Users</TabsTrigger>
              <TabsTrigger value="sales">Sales</TabsTrigger>
              <TabsTrigger value="finance">Finance</TabsTrigger>
              <TabsTrigger value="developer">Developers</TabsTrigger>
              <TabsTrigger value="investor">Investors</TabsTrigger>
              <TabsTrigger value="client">Clients</TabsTrigger>
              <TabsTrigger value="partner">Partners</TabsTrigger>
            </TabsList>
            
            <TabsContent value={activeTab}>
              <Card className="glass border-none">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-white font-semibold">
                      {activeTab === "all" ? "All Users" : `${roleDisplay(activeTab)}`}
                    </CardTitle>
                    {activeTab !== "all" && (
                      <Badge variant="outline" className={getRoleBadgeColor(activeTab)}>
                        {filteredUsers?.length || 0} users
                      </Badge>
                    )}
                  </div>
                  {activeTab !== "all" && (
                    <CardDescription>
                      {activeTab === "sales" && "Sales personnel can access sales records, products, and customer queries."}
                      {activeTab === "finance" && "Finance personnel can access income statements, sales records, and financial data."}
                      {activeTab === "developer" && "Developers have full access to all system features."}
                      {activeTab === "investor" && "Investors can view income statements and financial performance."}
                      {activeTab === "client" && "Clients have limited access to public information only."}
                      {activeTab === "partner" && "Partners have access to shared resources between companies."}
                    </CardDescription>
                  )}
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>User</TableHead>
                          <TableHead>Username</TableHead>
                          <TableHead>Role</TableHead>
                          <TableHead>Tenant</TableHead>
                          <TableHead>MFA Status</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {isLoading ? (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center py-8">
                              <Loader2 className="h-6 w-6 animate-spin mx-auto text-muted-foreground" />
                            </TableCell>
                          </TableRow>
                        ) : filteredUsers?.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                              No users found.
                            </TableCell>
                          </TableRow>
                        ) : (
                          filteredUsers?.map((u) => (
                            <TableRow key={u.id}>
                              <TableCell>
                                <div className="flex items-center">
                                  <Avatar className="h-8 w-8 mr-2">
                                    <AvatarFallback className="bg-primary text-primary-foreground">
                                      {getUserInitials(u.fullName)}
                                    </AvatarFallback>
                                  </Avatar>
                                  <div>
                                    <div className="font-medium text-white">{u.fullName}</div>
                                    <div className="text-xs text-muted-foreground">{u.email}</div>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>{u.username}</TableCell>
                              <TableCell>
                                <Badge variant="outline" className={getRoleBadgeColor(u.role)}>
                                  {roleDisplay(u.role)}
                                </Badge>
                              </TableCell>
                              <TableCell>{getTenantName(u.tenantId)}</TableCell>
                              <TableCell>
                                {u.mfaEnabled ? (
                                  <div className="flex items-center text-primary">
                                    <CheckCircle className="h-4 w-4 mr-1" />
                                    <span>Enabled</span>
                                  </div>
                                ) : (
                                  <div className="flex items-center text-muted-foreground">
                                    <XCircle className="h-4 w-4 mr-1" />
                                    <span>Disabled</span>
                                  </div>
                                )}
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleEditRole(u)}
                                    disabled={u.id === user?.id} // Can't edit own role
                                  >
                                    <Edit className="h-4 w-4 mr-1" />
                                    Edit Role
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
          
          {/* Access Control Matrix */}
          <Card className="glass border-none mb-6">
            <CardHeader>
              <CardTitle className="text-white font-semibold">Access Control Matrix</CardTitle>
              <CardDescription>
                Overview of permissions by role
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Resource</TableHead>
                      <TableHead>Sales</TableHead>
                      <TableHead>Finance</TableHead>
                      <TableHead>Developer</TableHead>
                      <TableHead>Investor</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Partner</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">Dashboard</TableCell>
                      <TableCell>✓</TableCell>
                      <TableCell>✓</TableCell>
                      <TableCell>✓</TableCell>
                      <TableCell>✓</TableCell>
                      <TableCell>✓</TableCell>
                      <TableCell>✓</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Sales Records</TableCell>
                      <TableCell>Read/Write</TableCell>
                      <TableCell>Read</TableCell>
                      <TableCell>Read/Write</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>-</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Finance Records</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>Read/Write</TableCell>
                      <TableCell>Read/Write</TableCell>
                      <TableCell>Read</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>-</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Income Statements</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>Read/Write</TableCell>
                      <TableCell>Read/Write</TableCell>
                      <TableCell>Read</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>-</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Customer Queries</TableCell>
                      <TableCell>Read/Write</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>Read/Write</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>Create</TableCell>
                      <TableCell>-</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Products</TableCell>
                      <TableCell>Read/Write</TableCell>
                      <TableCell>Read</TableCell>
                      <TableCell>Read/Write</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>Read</TableCell>
                      <TableCell>Read</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">User Management</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>Read/Write</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>-</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">System Backups</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>Read/Write</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>-</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      {/* Invite User Modal */}
      <Dialog open={isInviteModalOpen} onOpenChange={setIsInviteModalOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Invite New User</DialogTitle>
          </DialogHeader>
          
          <Form {...inviteForm}>
            <form onSubmit={inviteForm.handleSubmit(onInviteSubmit)} className="space-y-4">
              <FormField
                control={inviteForm.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="user@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={inviteForm.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Jane Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={inviteForm.control}
                  name="role"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Role</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select role" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="sales">Sales Personnel</SelectItem>
                          <SelectItem value="finance">Finance Personnel</SelectItem>
                          <SelectItem value="developer">Developer</SelectItem>
                          <SelectItem value="investor">Investor</SelectItem>
                          <SelectItem value="client">Client</SelectItem>
                          <SelectItem value="partner">Partner</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={inviteForm.control}
                  name="tenantId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tenant</FormLabel>
                      <Select
                        onValueChange={(value) => field.onChange(parseInt(value))}
                        defaultValue={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select tenant" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="1">IWB (Primary)</SelectItem>
                          <SelectItem value="2">IWC (Partner)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <DialogFooter>
                <Button 
                  variant="outline" 
                  type="button" 
                  onClick={() => setIsInviteModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={inviteUserMutation.isPending}
                >
                  {inviteUserMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  Send Invitation
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Edit Role Modal */}
      <Dialog open={isEditRoleModalOpen} onOpenChange={setIsEditRoleModalOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle>Edit User Role</DialogTitle>
          </DialogHeader>
          
          {selectedUser && (
            <div className="flex items-center mb-4">
              <Avatar className="h-10 w-10 mr-3">
                <AvatarFallback className="bg-primary text-primary-foreground">
                  {getUserInitials(selectedUser.fullName)}
                </AvatarFallback>
              </Avatar>
              <div>
                <div className="font-medium text-white">{selectedUser.fullName}</div>
                <div className="text-sm text-muted-foreground">{selectedUser.email}</div>
              </div>
            </div>
          )}
          
          <Form {...roleForm}>
            <form onSubmit={roleForm.handleSubmit(onRoleUpdateSubmit)} className="space-y-4">
              <FormField
                control={roleForm.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Role</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select role" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="sales">Sales Personnel</SelectItem>
                        <SelectItem value="finance">Finance Personnel</SelectItem>
                        <SelectItem value="developer">Developer</SelectItem>
                        <SelectItem value="investor">Investor</SelectItem>
                        <SelectItem value="client">Client</SelectItem>
                        <SelectItem value="partner">Partner</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  variant="outline" 
                  type="button" 
                  onClick={() => setIsEditRoleModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={updateRoleMutation.isPending}
                >
                  {updateRoleMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  Update Role
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
