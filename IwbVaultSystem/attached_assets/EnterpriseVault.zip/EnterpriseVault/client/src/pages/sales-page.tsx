import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Sidebar from "@/components/dashboard/sidebar";
import Header from "@/components/dashboard/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertSaleSchema } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { PlusCircle, Search, FileText, Edit, Trash2, Filter, Loader2 } from "lucide-react";
import { format } from "date-fns";

// New sale schema based on insertSaleSchema but with validation
const newSaleSchema = z.object({
  productId: z.number().min(1, "Please select a product"),
  quantity: z.number().min(1, "Quantity must be at least 1"),
  totalAmount: z.number().min(0.01, "Total amount must be greater than 0"),
  customerId: z.number().optional(),
  salesPersonId: z.number().optional(),
  notes: z.string().optional(),
  receiptNumber: z.string().optional(),
});

export default function SalesPage() {
  const { user } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isNewSaleOpen, setIsNewSaleOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  
  // Fetch sales data
  const { data: sales, isLoading: isLoadingSales } = useQuery({
    queryKey: ['/api/sales'],
  });
  
  // Fetch products for dropdown
  const { data: products } = useQuery({
    queryKey: ['/api/products'],
  });
  
  // Sale mutation
  const createSaleMutation = useMutation({
    mutationFn: async (sale: z.infer<typeof newSaleSchema>) => {
      const res = await apiRequest("POST", "/api/sales", sale);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sales'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard-stats'] });
      setIsNewSaleOpen(false);
      form.reset();
    },
  });
  
  // Form setup
  const form = useForm<z.infer<typeof newSaleSchema>>({
    resolver: zodResolver(newSaleSchema),
    defaultValues: {
      productId: undefined,
      quantity: 1,
      totalAmount: 0,
      notes: "",
      receiptNumber: `REC-${Date.now().toString().slice(-6)}`,
    },
  });
  
  // Handle form submission
  const onSubmit = (values: z.infer<typeof newSaleSchema>) => {
    createSaleMutation.mutate(values);
  };
  
  // Update total amount when product or quantity changes
  const watchProduct = form.watch("productId");
  const watchQuantity = form.watch("quantity");
  
  useState(() => {
    if (watchProduct && watchQuantity) {
      const product = products?.find(p => p.id === watchProduct);
      if (product) {
        const totalAmount = product.price * watchQuantity;
        form.setValue("totalAmount", totalAmount);
      }
    }
  });
  
  // Filter sales based on search term
  const filteredSales = sales?.filter(sale => {
    if (!searchTerm) return true;
    
    const searchTermLower = searchTerm.toLowerCase();
    const product = products?.find(p => p.id === sale.productId);
    
    return (
      product?.name?.toLowerCase().includes(searchTermLower) ||
      sale.receiptNumber?.toLowerCase().includes(searchTermLower) ||
      sale.notes?.toLowerCase().includes(searchTermLower)
    );
  });
  
  return (
    <div className="h-screen flex overflow-hidden">
      {/* Sidebar */}
      <Sidebar 
        mobileMenuOpen={mobileMenuOpen} 
        setMobileMenuOpen={setMobileMenuOpen} 
        currentPath="/sales"
      />
      
      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden bg-gradient-to-br from-dark-900 to-dark-800">
        {/* Top Header */}
        <Header 
          toggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)} 
          title="Sales Management" 
        />
        
        {/* Sales Page Content */}
        <div className="flex-1 overflow-y-auto px-4 md:px-6 py-6">
          {/* Page Title & Action Buttons */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
            <div className="mb-4 md:mb-0">
              <h1 className="text-2xl md:text-3xl font-heading font-bold text-white">Sales Records</h1>
              <p className="text-muted-foreground mt-1">
                Manage your sales transaction history
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search sales..."
                  className="pl-8 w-full sm:w-[200px] lg:w-[300px]"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <Button onClick={() => setIsNewSaleOpen(true)}>
                <PlusCircle className="mr-2 h-4 w-4" />
                New Sale
              </Button>
            </div>
          </div>
          
          {/* Sales Records Table */}
          <Card className="glass border-none">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-center">
                <CardTitle>Sales History</CardTitle>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm">
                    <FileText className="mr-2 h-4 w-4" />
                    Export CSV
                  </Button>
                  <Button variant="outline" size="icon" className="h-8 w-8">
                    <Filter className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoadingSales ? (
                <div className="space-y-2">
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Receipt #</TableHead>
                        <TableHead>Product</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredSales?.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center text-muted-foreground h-24">
                            No sales records found
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredSales?.map((sale) => {
                          const product = products?.find(p => p.id === sale.productId);
                          return (
                            <TableRow key={sale.id}>
                              <TableCell className="font-medium">{sale.receiptNumber || `#RCY-${sale.id}`}</TableCell>
                              <TableCell>{product?.name || 'Unknown Product'}</TableCell>
                              <TableCell>{sale.quantity}</TableCell>
                              <TableCell>M {sale.totalAmount.toLocaleString()}</TableCell>
                              <TableCell>{format(new Date(sale.date), 'MMM dd, yyyy')}</TableCell>
                              <TableCell>
                                <span className="px-2 py-1 rounded-full text-xs font-medium bg-primary/20 text-primary">
                                  Completed
                                </span>
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end space-x-2">
                                  <Button variant="ghost" size="icon" className="h-8 w-8">
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button variant="ghost" size="icon" className="h-8 w-8">
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          );
                        })
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
      
      {/* New Sale Dialog */}
      <Dialog open={isNewSaleOpen} onOpenChange={setIsNewSaleOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Create New Sale</DialogTitle>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="productId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Product</FormLabel>
                      <Select
                        onValueChange={(value) => field.onChange(parseInt(value))}
                        value={field.value?.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a product" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {products?.map((product) => (
                            <SelectItem key={product.id} value={product.id.toString()}>
                              {product.name} - M {product.price.toLocaleString()}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="quantity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Quantity</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min={1}
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="totalAmount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Total Amount</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <span className="absolute left-3 top-2.5">M</span>
                        <Input
                          type="number"
                          step="0.01"
                          className="pl-8"
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value))}
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="receiptNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Receipt Number</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes (Optional)</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button variant="outline" type="button" onClick={() => setIsNewSaleOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createSaleMutation.isPending}>
                  {createSaleMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  Save Sale
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
