import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useMFA } from "@/hooks/use-mfa";
import Sidebar from "@/components/dashboard/sidebar";
import Header from "@/components/dashboard/header";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { 
  Settings, 
  ShieldCheck, 
  Database, 
  User, 
  Key, 
  AlertTriangle, 
  Loader2, 
  CheckCircle, 
  XCircle,
  Save,
  RefreshCw,
  DownloadCloud
} from "lucide-react";

// Password change schema
const passwordSchema = z.object({
  currentPassword: z.string().min(6, "Password must be at least 6 characters"),
  newPassword: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(6, "Password must be at least 6 characters")
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

// Personal info schema
const profileSchema = z.object({
  fullName: z.string().min(3, "Full name must be at least 3 characters"),
  email: z.string().email("Invalid email address"),
  phoneNumber: z.string().optional(),
  backupEmail: z.string().email("Invalid email address").optional().or(z.literal('')),
});

export default function SettingsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("general");
  const [showQRCode, setShowQRCode] = useState(false);
  const [qrConfirmOpen, setQrConfirmOpen] = useState(false);
  const [backupCreating, setBackupCreating] = useState(false);
  
  const {
    mfaEnabled = user?.mfaEnabled || false,
    setupMode,
    mfaCode,
    otpAuthUrl,
    mfaSecret,
    isPending: mfaIsPending,
    handleCodeChange,
    handleKeyDown,
    setupMFA,
    verifyMFA,
    disableMFA,
    setSetupMode,
  } = useMFA();
  
  // Fetch backups
  const { data: backups, isLoading: isLoadingBackups, refetch: refetchBackups } = useQuery({
    queryKey: ['/api/backups'],
  });
  
  // Password change form
  const passwordForm = useForm<z.infer<typeof passwordSchema>>({
    resolver: zodResolver(passwordSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });
  
  // Profile form
  const profileForm = useForm<z.infer<typeof profileSchema>>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      fullName: user?.fullName || "",
      email: user?.email || "",
      phoneNumber: user?.phoneNumber || "",
      backupEmail: user?.backupEmail || "",
    },
  });
  
  // Reset forms when user data changes
  useState(() => {
    if (user) {
      profileForm.reset({
        fullName: user.fullName || "",
        email: user.email || "",
        phoneNumber: user.phoneNumber || "",
        backupEmail: user.backupEmail || "",
      });
    }
  });
  
  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: z.infer<typeof profileSchema>) => {
      const res = await apiRequest("PATCH", "/api/user", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      toast({
        title: "Profile updated",
        description: "Your profile information has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update profile",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Change password mutation
  const changePasswordMutation = useMutation({
    mutationFn: async (data: z.infer<typeof passwordSchema>) => {
      const res = await apiRequest("POST", "/api/user/change-password", {
        currentPassword: data.currentPassword,
        newPassword: data.newPassword,
      });
      return await res.json();
    },
    onSuccess: () => {
      passwordForm.reset();
      toast({
        title: "Password updated",
        description: "Your password has been changed successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to change password",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Create backup mutation
  const createBackupMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/backups", {});
      return await res.json();
    },
    onSuccess: () => {
      setBackupCreating(false);
      refetchBackups();
      toast({
        title: "Backup created",
        description: "System data has been backed up successfully.",
      });
    },
    onError: (error) => {
      setBackupCreating(false);
      toast({
        title: "Failed to create backup",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle profile form submission
  const onProfileSubmit = (values: z.infer<typeof profileSchema>) => {
    updateProfileMutation.mutate(values);
  };
  
  // Handle password form submission
  const onPasswordSubmit = (values: z.infer<typeof passwordSchema>) => {
    changePasswordMutation.mutate(values);
  };
  
  // Handle MFA setup
  const handleMFASetup = async () => {
    if (mfaEnabled) {
      // Disable MFA
      const result = await disableMFA();
      if (result.success) {
        toast({
          title: "MFA disabled",
          description: "Multi-factor authentication has been disabled for your account.",
        });
      } else {
        toast({
          title: "Failed to disable MFA",
          description: result.message || "An error occurred",
          variant: "destructive",
        });
      }
    } else {
      // Start MFA setup process
      await setupMFA();
      setShowQRCode(true);
    }
  };
  
  // Handle MFA verification
  const handleVerifyMFA = async () => {
    const token = mfaCode.join('');
    
    if (token.length !== 6 || !/^\d+$/.test(token)) {
      toast({
        title: "Invalid code",
        description: "Please enter a valid 6-digit code",
        variant: "destructive",
      });
      return;
    }
    
    const result = await verifyMFA(true);
    
    if (result.success) {
      setShowQRCode(false);
      setQrConfirmOpen(false);
      toast({
        title: "MFA enabled",
        description: "Multi-factor authentication has been enabled for your account.",
      });
    } else {
      toast({
        title: "Verification failed",
        description: result.message || "Please try again with a new code",
        variant: "destructive",
      });
    }
  };
  
  // Handle backup creation
  const createBackup = () => {
    setBackupCreating(true);
    createBackupMutation.mutate();
  };
  
  return (
    <div className="h-screen flex overflow-hidden">
      {/* Sidebar */}
      <Sidebar 
        mobileMenuOpen={mobileMenuOpen} 
        setMobileMenuOpen={setMobileMenuOpen} 
        currentPath="/settings"
      />
      
      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden bg-gradient-to-br from-dark-900 to-dark-800">
        {/* Top Header */}
        <Header 
          toggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)} 
          title="Settings" 
        />
        
        {/* Settings Page Content */}
        <div className="flex-1 overflow-y-auto px-4 md:px-6 py-6">
          {/* Page Title */}
          <div className="mb-6">
            <h1 className="text-2xl md:text-3xl font-heading font-bold text-white">Settings</h1>
            <p className="text-muted-foreground mt-1">
              Manage your account and system preferences
            </p>
          </div>
          
          {/* Settings Tabs */}
          <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="w-full md:w-[400px] grid grid-cols-3">
              <TabsTrigger value="general">
                <User className="h-4 w-4 mr-2" />
                Account
              </TabsTrigger>
              <TabsTrigger value="security">
                <ShieldCheck className="h-4 w-4 mr-2" />
                Security
              </TabsTrigger>
              <TabsTrigger value="system" disabled={user?.role !== "developer"}>
                <Database className="h-4 w-4 mr-2" />
                System
              </TabsTrigger>
            </TabsList>
            
            {/* Account Settings */}
            <TabsContent value="general">
              <div className="grid gap-6">
                <Card className="glass border-none">
                  <CardHeader>
                    <CardTitle>Personal Information</CardTitle>
                    <CardDescription>
                      Update your personal information
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...profileForm}>
                      <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-4">
                        <FormField
                          control={profileForm.control}
                          name="fullName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Full Name</FormLabel>
                              <FormControl>
                                <Input {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={profileForm.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email Address</FormLabel>
                              <FormControl>
                                <Input type="email" {...field} />
                              </FormControl>
                              <FormDescription>
                                This is your primary email used for login and notifications
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={profileForm.control}
                            name="phoneNumber"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Phone Number (Optional)</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={profileForm.control}
                            name="backupEmail"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Backup Email (Optional)</FormLabel>
                                <FormControl>
                                  <Input type="email" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="flex justify-end">
                          <Button 
                            type="submit" 
                            disabled={updateProfileMutation.isPending}
                          >
                            {updateProfileMutation.isPending && (
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            )}
                            Save Changes
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
                
                <Card className="glass border-none">
                  <CardHeader>
                    <CardTitle>Account Information</CardTitle>
                    <CardDescription>
                      View your account details
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-muted-foreground">Username</Label>
                        <div className="text-white font-medium mt-1">{user?.username}</div>
                      </div>
                      
                      <div>
                        <Label className="text-muted-foreground">Account Created</Label>
                        <div className="text-white font-medium mt-1">
                          {user?.createdAt ? format(new Date(user.createdAt), 'MMMM dd, yyyy') : "N/A"}
                        </div>
                      </div>
                      
                      <div>
                        <Label className="text-muted-foreground">Role</Label>
                        <div className="mt-1">
                          <Badge variant="outline" className="bg-primary/20 text-primary">
                            {user?.role.charAt(0).toUpperCase() + user?.role.slice(1)}
                          </Badge>
                        </div>
                      </div>
                      
                      <div>
                        <Label className="text-muted-foreground">Tenant</Label>
                        <div className="mt-1">
                          <Badge variant="outline" className="bg-secondary-500/20 text-secondary-500">
                            {user?.tenantId === 1 ? "IWB (Primary)" : "IWC (Partner)"}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            {/* Security Settings */}
            <TabsContent value="security">
              <div className="grid gap-6">
                <Card className="glass border-none">
                  <CardHeader>
                    <CardTitle>Change Password</CardTitle>
                    <CardDescription>
                      Update your account password
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...passwordForm}>
                      <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)} className="space-y-4">
                        <FormField
                          control={passwordForm.control}
                          name="currentPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Current Password</FormLabel>
                              <FormControl>
                                <Input type="password" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={passwordForm.control}
                          name="newPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>New Password</FormLabel>
                              <FormControl>
                                <Input type="password" {...field} />
                              </FormControl>
                              <FormDescription>
                                Password must be at least 6 characters long
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={passwordForm.control}
                          name="confirmPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Confirm New Password</FormLabel>
                              <FormControl>
                                <Input type="password" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="flex justify-end">
                          <Button 
                            type="submit"
                            disabled={changePasswordMutation.isPending}
                          >
                            {changePasswordMutation.isPending && (
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            )}
                            Change Password
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
                
                <Card className="glass border-none">
                  <CardHeader>
                    <CardTitle>Two-Factor Authentication</CardTitle>
                    <CardDescription>
                      Add an extra layer of security to your account
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Multi-Factor Authentication</Label>
                        <div className="text-sm text-muted-foreground">
                          Protect your account with an additional verification step
                        </div>
                      </div>
                      <div className="flex items-center">
                        {mfaEnabled ? (
                          <div className="flex items-center text-primary mr-4">
                            <CheckCircle className="h-4 w-4 mr-1" />
                            <span>Enabled</span>
                          </div>
                        ) : (
                          <div className="flex items-center text-muted-foreground mr-4">
                            <XCircle className="h-4 w-4 mr-1" />
                            <span>Disabled</span>
                          </div>
                        )}
                        <Button
                          onClick={handleMFASetup}
                          variant={mfaEnabled ? "destructive" : "default"}
                          disabled={mfaIsPending}
                        >
                          {mfaIsPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                          {mfaEnabled ? "Disable MFA" : "Enable MFA"}
                        </Button>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <Alert>
                      <ShieldCheck className="h-4 w-4" />
                      <AlertTitle>Security Recommendation</AlertTitle>
                      <AlertDescription>
                        We strongly recommend enabling multi-factor authentication to protect your account from unauthorized access.
                      </AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>
                
                <Card className="glass border-none">
                  <CardHeader>
                    <CardTitle>Session Management</CardTitle>
                    <CardDescription>
                      Manage your active sessions
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Current Session</Label>
                        <div className="text-sm text-muted-foreground">
                          This device, last active just now
                        </div>
                      </div>
                      <Badge variant="outline" className="bg-primary/20 text-primary">
                        Active
                      </Badge>
                    </div>
                    
                    <Separator />
                    
                    <div className="flex justify-end">
                      <Button variant="outline" className="mr-2">
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Refresh Sessions
                      </Button>
                      <Button variant="destructive">
                        <LogOut className="mr-2 h-4 w-4" />
                        Log Out All Devices
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            {/* System Settings (Developers Only) */}
            <TabsContent value="system">
              {user?.role !== "developer" ? (
                <Card className="glass border-none">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-center text-center p-6">
                      <div>
                        <AlertTriangle className="h-10 w-10 text-amber-500 mx-auto mb-4" />
                        <h3 className="text-lg font-semibold text-white mb-2">Access Restricted</h3>
                        <p className="text-muted-foreground">
                          System settings are only accessible to users with Developer permissions.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-6">
                  <Card className="glass border-none">
                    <CardHeader>
                      <CardTitle>Database Backups</CardTitle>
                      <CardDescription>
                        Manage system data backups
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Automatic Backups</Label>
                          <div className="text-sm text-muted-foreground">
                            System will create weekly backups automatically
                          </div>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex justify-end">
                        <Button onClick={createBackup} disabled={backupCreating}>
                          {backupCreating ? (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          ) : (
                            <Database className="mr-2 h-4 w-4" />
                          )}
                          Create Backup Now
                        </Button>
                      </div>
                      
                      <Separator />
                      
                      <div>
                        <h3 className="text-sm font-medium text-white mb-3">Recent Backups</h3>
                        <div className="rounded-md border">
                          <div className="divide-y divide-border">
                            {isLoadingBackups ? (
                              <div className="p-4 text-center">
                                <Loader2 className="h-6 w-6 animate-spin mx-auto text-muted-foreground" />
                              </div>
                            ) : backups?.length === 0 ? (
                              <div className="p-4 text-center text-muted-foreground">
                                No backups available
                              </div>
                            ) : (
                              backups?.slice(0, 5).map((backup: any) => (
                                <div key={backup.id} className="flex items-center justify-between p-4">
                                  <div>
                                    <div className="font-medium text-white">{backup.filename}</div>
                                    <div className="text-xs text-muted-foreground mt-1">
                                      {format(new Date(backup.createdAt), "MMM dd, yyyy HH:mm")} • {(backup.size / (1024 * 1024)).toFixed(2)} MB
                                    </div>
                                  </div>
                                  <Button variant="ghost" size="sm">
                                    <DownloadCloud className="h-4 w-4" />
                                    <span className="sr-only">Download</span>
                                  </Button>
                                </div>
                              ))
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="justify-end">
                      <Button variant="outline">View All Backups</Button>
                    </CardFooter>
                  </Card>
                  
                  <Card className="glass border-none">
                    <CardHeader>
                      <CardTitle>System Information</CardTitle>
                      <CardDescription>
                        View server and application details
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label className="text-muted-foreground">Application Version</Label>
                          <div className="text-white font-medium mt-1">1.0.0</div>
                        </div>
                        
                        <div>
                          <Label className="text-muted-foreground">Database Status</Label>
                          <div className="flex items-center mt-1 text-primary">
                            <CheckCircle className="h-4 w-4 mr-1" />
                            <span>Connected</span>
                          </div>
                        </div>
                        
                        <div>
                          <Label className="text-muted-foreground">Last Backup</Label>
                          <div className="text-white font-medium mt-1">
                            {backups && backups.length > 0
                              ? format(new Date(backups[0].createdAt), "MMM dd, yyyy HH:mm")
                              : "Never"}
                          </div>
                        </div>
                        
                        <div>
                          <Label className="text-muted-foreground">Environment</Label>
                          <div className="text-white font-medium mt-1">Production</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      {/* MFA Setup Dialog */}
      <Dialog open={showQRCode} onOpenChange={setShowQRCode}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Set Up Multi-Factor Authentication</DialogTitle>
            <DialogDescription>
              Scan the QR code with your authenticator app to enable MFA.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-lg mx-auto max-w-[200px]">
              {otpAuthUrl && (
                <img
                  src={`https://chart.googleapis.com/chart?chs=200x200&chld=M|0&cht=qr&chl=${encodeURIComponent(
                    otpAuthUrl
                  )}`}
                  alt="QR Code for MFA"
                  className="w-full"
                />
              )}
            </div>
            
            {mfaSecret && (
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-1">Or enter this code manually:</p>
                <code className="bg-muted px-2 py-1 rounded-md text-white">{mfaSecret}</code>
              </div>
            )}
            
            <Alert variant="default" className="bg-primary/10 border-primary/20">
              <ShieldCheck className="h-4 w-4 text-primary" />
              <AlertTitle>Important</AlertTitle>
              <AlertDescription className="text-sm">
                Make sure to store your recovery codes in a safe place. If you lose access to your authenticator app, you'll need these to regain access to your account.
              </AlertDescription>
            </Alert>
            
            <div className="mt-4">
              <Label htmlFor="verification-code" className="block text-sm font-medium mb-1">
                Verification Code
              </Label>
              <div className="flex justify-between space-x-2 mb-4">
                {[0, 1, 2, 3, 4, 5].map((index) => (
                  <Input
                    key={index}
                    id={`mfa-input-${index}`}
                    type="text"
                    maxLength={1}
                    className="w-12 h-12 text-center text-xl font-medium rounded-lg"
                    value={mfaCode[index] || ""}
                    onChange={(e) => handleCodeChange(index, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(index, e)}
                    autoFocus={index === 0}
                  />
                ))}
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => {
                setShowQRCode(false);
                setSetupMode(false);
              }}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleVerifyMFA}
              disabled={mfaCode.join("").length !== 6 || mfaIsPending}
            >
              {mfaIsPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Verify and Enable
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
