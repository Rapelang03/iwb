import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Sidebar from "@/components/dashboard/sidebar";
import Header from "@/components/dashboard/header";
import KPICard from "@/components/dashboard/kpi-card";
import ChartCard from "@/components/dashboard/chart-card";
import ProductTable from "@/components/dashboard/product-table";
import RecentRecords from "@/components/dashboard/recent-records";
import QueriesList from "@/components/dashboard/queries-list";
import QueryModal from "@/components/query-modal";
import { 
  AreaChart, 
  BarChart, 
  PieChart,
  LineChart
} from "recharts";
import { 
  Download, 
  PlusCircle, 
  DollarSign, 
  Cpu, 
  MailQuestion,
  TrendingUp 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function DashboardPage() {
  const { user } = useAuth();
  const [isQueryModalOpen, setIsQueryModalOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Fetch dashboard stats
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ['/api/dashboard-stats'],
    refetchInterval: 300000, // 5 minutes
  });
  
  // Mock data for charts
  const revenueData = [
    { name: 'Jan', revenue: 32500 },
    { name: 'Feb', revenue: 42800 },
    { name: 'Mar', revenue: 38200 },
    { name: 'Apr', revenue: 45800 },
    { name: 'May', revenue: 52300 },
    { name: 'Jun', revenue: 59800 },
  ];
  
  const categoryData = [
    { name: 'Memory', value: 35 },
    { name: 'Storage', value: 25 },
    { name: 'Processor', value: 20 },
    { name: 'Motherboard', value: 10 },
    { name: 'GPU', value: 10 },
  ];
  
  // Handle query modal
  const toggleQueryModal = () => {
    setIsQueryModalOpen(!isQueryModalOpen);
  };
  
  return (
    <div className="h-screen flex overflow-hidden">
      {/* Sidebar */}
      <Sidebar 
        mobileMenuOpen={mobileMenuOpen} 
        setMobileMenuOpen={setMobileMenuOpen} 
        currentPath="/"
      />
      
      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden bg-gradient-to-br from-dark-900 to-dark-800">
        {/* Top Header */}
        <Header 
          toggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)} 
          title="Dashboard Overview" 
        />
        
        {/* Dashboard Content */}
        <div className="flex-1 overflow-y-auto px-4 md:px-6 py-6">
          {/* Page Title & Action Buttons */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
            <div className="mb-4 md:mb-0">
              <h1 className="text-2xl md:text-3xl font-heading font-bold text-white">Dashboard Overview</h1>
              <p className="text-muted-foreground mt-1">
                Welcome back, {user?.fullName || 'User'}. Here's what's happening with IWB Recycling.
              </p>
            </div>
            
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" className="h-9">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
              <Button size="sm" className="h-9">
                <PlusCircle className="mr-2 h-4 w-4" />
                New Record
              </Button>
            </div>
          </div>
          
          {/* KPI Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {/* Total Sales Card */}
            {isLoadingStats ? (
              <Skeleton className="h-[120px] rounded-xl" />
            ) : (
              <KPICard
                title="Total Sales"
                value={`M ${stats?.totalSales?.toLocaleString() || 0}`}
                trend={12.5}
                trendLabel="from last month"
                icon={<DollarSign />}
                iconColor="primary"
              />
            )}
            
            {/* Recycled Components Card */}
            {isLoadingStats ? (
              <Skeleton className="h-[120px] rounded-xl" />
            ) : (
              <KPICard
                title="Recycled Components"
                value={stats?.recycledComponents?.toLocaleString() || 0}
                trend={8.3}
                trendLabel="from last month"
                icon={<Cpu />}
                iconColor="secondary"
              />
            )}
            
            {/* Customer Queries Card */}
            {isLoadingStats ? (
              <Skeleton className="h-[120px] rounded-xl" />
            ) : (
              <KPICard
                title="Customer Queries"
                value={stats?.pendingQueries?.toString() || '0'}
                trend={-5.2}
                trendLabel="from last month"
                icon={<MailQuestion />}
                iconColor="accent"
              />
            )}
            
            {/* Net Revenue Card */}
            {isLoadingStats ? (
              <Skeleton className="h-[120px] rounded-xl" />
            ) : (
              <KPICard
                title="Net Revenue"
                value={`M ${stats?.netIncome?.toLocaleString() || 0}`}
                trend={18.7}
                trendLabel="from last month"
                icon={<TrendingUp />}
                iconColor="primary"
              />
            )}
          </div>
          
          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Monthly Revenue Chart */}
            <ChartCard title="Monthly Revenue">
              <div className="flex items-center justify-between mb-4">
                <Select defaultValue="6months">
                  <SelectTrigger className="w-[180px] bg-dark-800 border-dark-700 text-dark-300">
                    <SelectValue placeholder="Time period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="6months">Last 6 months</SelectItem>
                    <SelectItem value="12months">Last 12 months</SelectItem>
                    <SelectItem value="24months">Last 24 months</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="h-[300px] w-full">
                <AreaChart
                  width={500}
                  height={300}
                  data={revenueData}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--muted))" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      borderColor: 'hsl(var(--border))' 
                    }} 
                  />
                  <Area 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="hsl(var(--primary))" 
                    fillOpacity={1} 
                    fill="url(#colorRevenue)" 
                  />
                </AreaChart>
              </div>
            </ChartCard>
            
            {/* Product Categories Chart */}
            <ChartCard title="Product Categories">
              <div className="h-[300px] w-full">
                <PieChart width={400} height={300}>
                  <Pie
                    data={categoryData}
                    cx={200}
                    cy={150}
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  >
                    {categoryData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={`hsl(var(--chart-${(index % 5) + 1}))`} 
                      />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value) => [`${value}%`, 'Percentage']}
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      borderColor: 'hsl(var(--border))' 
                    }}
                  />
                </PieChart>
              </div>
            </ChartCard>
          </div>
          
          {/* Recent Records & Pending Queries */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Recent Records Table */}
            <RecentRecords />
            
            {/* Pending Customer Queries */}
            <QueriesList onReplyClick={toggleQueryModal} />
          </div>
          
          {/* Product Performance */}
          <ProductTable />
        </div>
      </main>
      
      {/* Query Modal */}
      <QueryModal isOpen={isQueryModalOpen} onClose={() => setIsQueryModalOpen(false)} />
    </div>
  );
}
