import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { ThemeProvider } from "@/components/ui/theme-provider";

// Create a consistent environment that works in all modern browsers
document.title = "IWB Electronic Recycling Platform";

createRoot(document.getElementById("root")!).render(
  <ThemeProvider defaultTheme="dark" storageKey="iwb-theme">
    <App />
  </ThemeProvider>
);
