import { useState } from 'react';
import { useAuth } from './use-auth';

export function useMFA() {
  const { verifyMFAMutation, setupMFAMutation, disableMFAMutation, user } = useAuth();
  const [mfaSecret, setMfaSecret] = useState<string | null>(null);
  const [otpAuthUrl, setOtpAuthUrl] = useState<string | null>(null);
  const [setupMode, setSetupMode] = useState<boolean>(false);
  
  // 6-digit code input state
  const [mfaCode, setMfaCode] = useState<string[]>(Array(6).fill(''));
  
  // Handle input change
  const handleCodeChange = (index: number, value: string) => {
    if (value.length > 1) {
      // Handle paste event
      const pastedValue = value.slice(0, 6);
      const newCode = Array(6).fill('');
      
      for (let i = 0; i < pastedValue.length; i++) {
        newCode[i] = pastedValue[i];
      }
      
      setMfaCode(newCode);
      return;
    }
    
    // Regular input
    const newCode = [...mfaCode];
    newCode[index] = value;
    setMfaCode(newCode);
    
    // Auto-focus next input
    if (value && index < 5) {
      const nextInput = document.getElementById(`mfa-input-${index + 1}`);
      if (nextInput) {
        nextInput.focus();
      }
    }
  };
  
  // Handle key down (for backspace)
  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !mfaCode[index] && index > 0) {
      const prevInput = document.getElementById(`mfa-input-${index - 1}`);
      if (prevInput) {
        prevInput.focus();
      }
    }
  };
  
  // Start MFA setup
  const setupMFA = async () => {
    setSetupMode(true);
    try {
      const result = await setupMFAMutation.mutateAsync();
      setMfaSecret(result.secret);
      setOtpAuthUrl(result.otpAuthUrl);
    } catch (error) {
      console.error('Error setting up MFA:', error);
    }
  };
  
  // Verify MFA code
  const verifyMFA = async (isEnabling: boolean = false) => {
    const token = mfaCode.join('');
    
    if (token.length !== 6 || !/^\d+$/.test(token)) {
      return { success: false, message: 'Please enter a valid 6-digit code' };
    }
    
    try {
      await verifyMFAMutation.mutateAsync({ token, isEnabling });
      return { success: true };
    } catch (error) {
      return { success: false, message: 'Invalid verification code' };
    }
  };
  
  // Disable MFA
  const disableMFA = async () => {
    try {
      await disableMFAMutation.mutateAsync();
      return { success: true };
    } catch (error) {
      return { success: false, message: 'Failed to disable MFA' };
    }
  };
  
  return {
    mfaEnabled: user?.mfaEnabled || false,
    mfaCode,
    mfaSecret,
    otpAuthUrl,
    setupMode,
    isPending: verifyMFAMutation.isPending || setupMFAMutation.isPending || disableMFAMutation.isPending,
    handleCodeChange,
    handleKeyDown,
    setupMFA,
    verifyMFA,
    disableMFA,
    setSetupMode,
  };
}
