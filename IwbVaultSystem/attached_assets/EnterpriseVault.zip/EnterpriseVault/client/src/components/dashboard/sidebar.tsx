import { RecycleIcon, LayoutDashboard, Store, PieChart, MessageSquareMore, Database, Users2, Settings, LogOut } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface SidebarProps {
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
  currentPath: string;
}

export default function Sidebar({ mobileMenuOpen, setMobileMenuOpen, currentPath }: SidebarProps) {
  const { user, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();
  
  // Get first letter of first and last names for avatar
  const getInitials = () => {
    if (!user?.fullName) return "U";
    const names = user.fullName.split(" ");
    if (names.length === 1) return names[0].charAt(0).toUpperCase();
    return (names[0].charAt(0) + names[names.length - 1].charAt(0)).toUpperCase();
  };
  
  // Handle log out
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  // Check if route is active
  const isActive = (path: string) => {
    return currentPath === path;
  };
  
  // Function to close mobile menu
  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };
  
  // Calculate what sidebar items to show based on user role
  const renderNavItems = () => {
    // Basic navigation items all users can see
    const items = [
      {
        label: "Dashboard",
        icon: <LayoutDashboard className="mr-3 text-lg" />,
        path: "/",
        roles: ["sales", "finance", "developer", "investor", "client", "partner"]
      },
      {
        label: "Sales",
        icon: <Store className="mr-3 text-lg" />,
        path: "/sales",
        roles: ["sales", "finance", "developer"]
      },
      {
        label: "Finance",
        icon: <PieChart className="mr-3 text-lg" />,
        path: "/finance",
        roles: ["finance", "developer", "investor"]
      },
      {
        label: "Customer Queries",
        icon: <MessageSquareMore className="mr-3 text-lg" />,
        path: "/queries",
        roles: ["sales", "developer"]
      },
      {
        label: "Products & Inventory",
        icon: <Database className="mr-3 text-lg" />,
        path: "/products",
        roles: ["sales", "finance", "developer"]
      }
    ];
    
    // Admin items for developers
    const adminItems = [
      {
        label: "User Management",
        icon: <Users2 className="mr-3 text-lg" />,
        path: "/users",
        roles: ["developer"]
      },
      {
        label: "Settings",
        icon: <Settings className="mr-3 text-lg" />,
        path: "/settings",
        roles: ["developer"]
      }
    ];
    
    // Filter items based on user role
    const userRole = user?.role || "client";
    const filteredItems = items.filter(item => item.roles.includes(userRole));
    const filteredAdminItems = adminItems.filter(item => item.roles.includes(userRole));
    
    return (
      <>
        <div className="px-4 pt-4">
          <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-2">Dashboard</p>
          <ul className="space-y-1">
            {filteredItems.map((item) => (
              <li key={item.path}>
                <Link href={item.path}>
                  <a
                    className={cn(
                      "flex items-center text-muted-foreground hover:text-white px-4 py-2.5 rounded-lg transition hover:bg-muted/50",
                      isActive(item.path) && "active-nav-item text-white"
                    )}
                    onClick={closeMobileMenu}
                  >
                    {item.icon}
                    <span>{item.label}</span>
                    {item.label === "Customer Queries" && (
                      <span className="ml-auto bg-primary text-primary-foreground text-xs font-semibold px-1.5 py-0.5 rounded-full">5</span>
                    )}
                  </a>
                </Link>
              </li>
            ))}
          </ul>
        </div>
        
        {filteredAdminItems.length > 0 && (
          <div className="px-4 pt-6">
            <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-2">Administration</p>
            <ul className="space-y-1">
              {filteredAdminItems.map((item) => (
                <li key={item.path}>
                  <Link href={item.path}>
                    <a
                      className={cn(
                        "flex items-center text-muted-foreground hover:text-white px-4 py-2.5 rounded-lg transition hover:bg-muted/50",
                        isActive(item.path) && "active-nav-item text-white"
                      )}
                      onClick={closeMobileMenu}
                    >
                      {item.icon}
                      <span>{item.label}</span>
                    </a>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}
      </>
    );
  };
  
  // Sidebar and mobile sidebar backdrop
  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="glass-dark w-64 flex-shrink-0 md:flex flex-col z-20 hidden md:block">
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center justify-center h-16 px-4 border-b border-muted/50">
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center shadow-md">
                <RecycleIcon className="text-white text-lg" />
              </div>
              <h1 className="ml-2 text-xl font-bold text-white font-heading">IWB <span className="text-primary">Recycle</span></h1>
            </div>
          </div>
          
          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto">
            {renderNavItems()}
          </nav>
          
          {/* User Profile */}
          <div className="border-t border-muted/50 p-4">
            <div className="flex items-center">
              <Avatar className="h-10 w-10 bg-primary text-white">
                <AvatarFallback>{getInitials()}</AvatarFallback>
              </Avatar>
              <div className="ml-3 flex-1 truncate">
                <p className="text-white font-medium truncate">{user?.fullName || "User"}</p>
                <p className="text-muted-foreground text-xs capitalize">{user?.role || "Client"}</p>
              </div>
              <Button variant="ghost" size="icon" onClick={handleLogout} className="text-muted-foreground hover:text-white">
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </aside>
      
      {/* Mobile Sidebar */}
      <div className={cn("fixed inset-0 z-40 lg:hidden", !mobileMenuOpen && "hidden")} id="mobile-sidebar-container">
        <div 
          className="fixed inset-0 bg-background/80 backdrop-blur-sm" 
          onClick={closeMobileMenu}
        ></div>
        <div className="fixed top-0 left-0 bottom-0 w-64 glass-dark z-40 overflow-y-auto">
          <div className="flex flex-col h-full">
            {/* Mobile Logo */}
            <div className="flex items-center justify-between h-16 px-4 border-b border-muted/50">
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center shadow-md">
                  <RecycleIcon className="text-white text-lg" />
                </div>
                <h1 className="ml-2 text-xl font-bold text-white font-heading">IWB <span className="text-primary">Recycle</span></h1>
              </div>
              <Button variant="ghost" size="icon" onClick={closeMobileMenu} className="text-muted-foreground">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </Button>
            </div>
            
            {/* Mobile Navigation */}
            <nav className="flex-1 overflow-y-auto">
              {renderNavItems()}
            </nav>
            
            {/* Mobile User Profile */}
            <div className="border-t border-muted/50 p-4">
              <div className="flex items-center">
                <Avatar className="h-10 w-10 bg-primary text-white">
                  <AvatarFallback>{getInitials()}</AvatarFallback>
                </Avatar>
                <div className="ml-3 flex-1 truncate">
                  <p className="text-white font-medium truncate">{user?.fullName || "User"}</p>
                  <p className="text-muted-foreground text-xs capitalize">{user?.role || "Client"}</p>
                </div>
                <Button variant="ghost" size="icon" onClick={handleLogout} className="text-muted-foreground hover:text-white">
                  <LogOut className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
