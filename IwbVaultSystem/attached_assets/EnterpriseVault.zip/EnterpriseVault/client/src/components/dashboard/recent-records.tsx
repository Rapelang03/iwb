import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

export default function RecentRecords() {
  // Fetch recent sales
  const { data: sales, isLoading } = useQuery({
    queryKey: ['/api/sales'],
  });
  
  // Fetch products to get product names
  const { data: products } = useQuery({
    queryKey: ['/api/products'],
  });
  
  // Get product name by ID
  const getProductName = (productId: number) => {
    const product = products?.find(p => p.id === productId);
    return product?.name || "Unknown Product";
  };
  
  // Get the most recent sales (limit to 4)
  const recentSales = sales?.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 4);
  
  return (
    <Card className="glass border-none">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-white font-semibold">Recent Records</CardTitle>
          <Link href="/sales">
            <a className="text-primary text-sm hover:text-primary/80 transition">View All</a>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        ) : recentSales?.length === 0 ? (
          <div className="text-center text-muted-foreground py-6">
            <p>No recent sales records found.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="text-muted-foreground text-left text-xs uppercase tracking-wider">
                  <TableHead className="pb-3 font-semibold">Product ID</TableHead>
                  <TableHead className="pb-3 font-semibold">Name</TableHead>
                  <TableHead className="pb-3 font-semibold">Category</TableHead>
                  <TableHead className="pb-3 font-semibold">Amount</TableHead>
                  <TableHead className="pb-3 font-semibold">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentSales ? (
                  recentSales.map((sale) => (
                    <TableRow key={sale.id} className="text-white">
                      <TableCell className="py-3 pr-4">{sale.receiptNumber || `#RCY-${sale.id}`}</TableCell>
                      <TableCell className="py-3 pr-4">{getProductName(sale.productId)}</TableCell>
                      <TableCell className="py-3 pr-4">
                        {products?.find(p => p.id === sale.productId)?.categoryId || 'Unknown'}
                      </TableCell>
                      <TableCell className="py-3 pr-4">M {sale.totalAmount.toLocaleString()}</TableCell>
                      <TableCell className="py-3">
                        <Badge variant="outline" className="bg-primary/20 text-primary border-primary/20">
                          Completed
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  // Fallback rendering for development when data isn't loaded yet
                  [
                    { id: 1, receipt: "#RCY-2023", name: "DDR4 RAM 16GB", category: "Memory", amount: 850 },
                    { id: 2, receipt: "#RCY-2024", name: "SSD 500GB", category: "Storage", amount: 1200 },
                    { id: 3, receipt: "#RCY-2025", name: "CPU Intel i7", category: "Processor", amount: 2500 },
                    { id: 4, receipt: "#RCY-2026", name: "Graphics Card", category: "GPU", amount: 3200 }
                  ].map((item) => (
                    <TableRow key={item.id} className="text-white">
                      <TableCell className="py-3 pr-4">{item.receipt}</TableCell>
                      <TableCell className="py-3 pr-4">{item.name}</TableCell>
                      <TableCell className="py-3 pr-4">{item.category}</TableCell>
                      <TableCell className="py-3 pr-4">M {item.amount}</TableCell>
                      <TableCell className="py-3">
                        <Badge variant="outline" className="bg-primary/20 text-primary border-primary/20">
                          Completed
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
