import { ReactNode } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Download } from "lucide-react";

interface ChartCardProps {
  title: string;
  children: ReactNode;
  actions?: ReactNode;
  downloadable?: boolean;
}

export default function ChartCard({ 
  title, 
  children, 
  actions,
  downloadable = true
}: ChartCardProps) {
  return (
    <Card className="glass border-none">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-white font-semibold">{title}</CardTitle>
          <div className="flex items-center space-x-2">
            {downloadable && (
              <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-white">
                <Download className="h-4 w-4" />
              </Button>
            )}
            {actions || (
              <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-white">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="chart-container overflow-hidden">
          {children}
        </div>
      </CardContent>
    </Card>
  );
}
