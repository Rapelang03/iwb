import { BellIcon, CircleHelp, MenuIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/use-auth";

interface HeaderProps {
  toggleMobileMenu: () => void;
  title: string;
}

export default function Header({ toggleMobileMenu, title }: HeaderProps) {
  const { user } = useAuth();
  
  // Get initials for avatar fallback
  const getInitials = () => {
    if (!user?.fullName) return "U";
    const names = user.fullName.split(" ");
    if (names.length === 1) return names[0].charAt(0).toUpperCase();
    return (names[0].charAt(0) + names[names.length - 1].charAt(0)).toUpperCase();
  };
  
  return (
    <header className="glass h-16 flex items-center px-4 md:px-6 z-10">
      <Button variant="ghost" size="icon" onClick={toggleMobileMenu} className="text-muted-foreground hover:text-white md:hidden">
        <MenuIcon className="h-5 w-5" />
      </Button>
      
      <div className="ml-3 md:ml-0 flex-1">
        <div id="header-title" className="text-white font-semibold text-lg">{title}</div>
      </div>
      
      <div className="flex items-center space-x-3">
        <div className="relative">
          <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full text-muted-foreground hover:text-white hover:bg-muted/50">
            <BellIcon className="h-5 w-5" />
            <span className="absolute top-0 right-0 w-2 h-2 rounded-full bg-accent pulse-animation"></span>
          </Button>
        </div>
        
        <div className="relative">
          <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full text-muted-foreground hover:text-white hover:bg-muted/50">
            <CircleHelp className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="hidden md:block h-6 w-px bg-muted/50"></div>
        
        <div className="hidden md:flex items-center space-x-2">
          <Avatar className="h-9 w-9 bg-primary text-white">
            <AvatarFallback>{getInitials()}</AvatarFallback>
          </Avatar>
          <div>
            <span className="text-white text-sm">{user?.fullName || "User"}</span>
          </div>
        </div>
      </div>
    </header>
  );
}
