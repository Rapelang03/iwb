import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface KPICardProps {
  title: string;
  value: string | number;
  trend?: number;
  trendLabel?: string;
  icon: React.ReactNode;
  iconColor: "primary" | "secondary" | "accent" | "destructive";
}

export default function KPICard({ 
  title, 
  value, 
  trend, 
  trendLabel,
  icon, 
  iconColor
}: KPICardProps) {
  // Determine if trend is positive or negative
  const isPositive = trend && trend > 0;
  
  // Get the background color based on the iconColor
  const getBgColorClass = () => {
    switch (iconColor) {
      case "primary":
        return "bg-primary bg-opacity-20 text-primary";
      case "secondary":
        return "bg-secondary-500 bg-opacity-20 text-secondary-500";
      case "accent":
        return "bg-accent bg-opacity-20 text-accent";
      case "destructive":
        return "bg-destructive bg-opacity-20 text-destructive";
      default:
        return "bg-primary bg-opacity-20 text-primary";
    }
  };
  
  return (
    <div className="glass rounded-xl p-5">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-muted-foreground text-sm mb-1">{title}</p>
          <h3 className="text-white text-2xl font-semibold">{value}</h3>
          {trend !== undefined && (
            <p className={cn(
              "flex items-center text-sm mt-1",
              isPositive ? "text-primary" : "text-accent"
            )}>
              {isPositive ? (
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 15.75l7.5-7.5 7.5 7.5" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
                </svg>
              )}
              {Math.abs(trend)}% {trendLabel || ""}
            </p>
          )}
        </div>
        <div className={cn("h-12 w-12 rounded-lg flex items-center justify-center", getBgColorClass())}>
          {icon}
        </div>
      </div>
    </div>
  );
}
