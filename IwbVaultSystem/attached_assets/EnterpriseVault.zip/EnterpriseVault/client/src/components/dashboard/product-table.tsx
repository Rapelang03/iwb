import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Cpu, HardDrive, MemoryStick, Cog, Filter, MoreHorizontal } from "lucide-react";

export default function ProductTable() {
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  
  // Fetch products data
  const { data: products, isLoading } = useQuery({
    queryKey: ['/api/products'],
  });
  
  // Fetch categories data
  const { data: categories } = useQuery({
    queryKey: ['/api/product-categories'],
  });
  
  // Filter products based on selected category
  const filteredProducts = products?.filter(product => 
    categoryFilter === "all" || product.categoryId.toString() === categoryFilter
  );
  
  // Get category name by ID
  const getCategoryName = (categoryId: number) => {
    const category = categories?.find(c => c.id === categoryId);
    return category?.name || "Unknown";
  };
  
  // Get icon based on category name
  const getCategoryIcon = (categoryName: string) => {
    const name = categoryName.toLowerCase();
    if (name.includes("processor") || name.includes("cpu")) {
      return <Cpu className="h-4 w-4" />;
    } else if (name.includes("storage") || name.includes("ssd") || name.includes("hdd")) {
      return <HardDrive className="h-4 w-4" />;
    } else if (name.includes("memory") || name.includes("ram")) {
      return <MemoryStick className="h-4 w-4" />;
    } else {
      return <Cog className="h-4 w-4" />;
    }
  };
  
  // Get color class based on growth value
  const getGrowthColorClass = (growth: number) => {
    return growth >= 0 ? "text-primary" : "text-accent";
  };
  
  // Mock data for demonstration
  const productPerformanceData = [
    { id: 1, name: "CPU Processors", category: "Processor", unitsRecycled: 1245, revenue: 75430, growth: 15.3 },
    { id: 2, name: "SSD Storage", category: "Storage", unitsRecycled: 2345, revenue: 48250, growth: 22.8 },
    { id: 3, name: "RAM MemoryStick", category: "MemoryStick", unitsRecycled: 3512, revenue: 32780, growth: 8.5 },
    { id: 4, name: "Motherboards", category: "Motherboard", unitsRecycled: 856, revenue: 18920, growth: -2.3 }
  ];
  
  return (
    <Card className="glass border-none mb-6">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <CardTitle className="text-white font-semibold">Product Performance</CardTitle>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-white">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
            <Select
              value={categoryFilter}
              onValueChange={setCategoryFilter}
            >
              <SelectTrigger className="w-[180px] h-9 bg-muted border-muted-foreground/20 text-muted-foreground">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories?.map((category) => (
                  <SelectItem key={category.id} value={category.id.toString()}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="pl-4 font-semibold">Product</TableHead>
                  <TableHead className="font-semibold">Category</TableHead>
                  <TableHead className="font-semibold">Units Recycled</TableHead>
                  <TableHead className="font-semibold">Revenue</TableHead>
                  <TableHead className="font-semibold">Growth</TableHead>
                  <TableHead className="pr-4 font-semibold text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {/* Use actual data if available, fall back to mock data if products aren't loaded yet */}
                {(filteredProducts?.length ? filteredProducts : productPerformanceData).map((product) => {
                  const categoryName = product.category || getCategoryName(product.categoryId);
                  return (
                    <TableRow key={product.id} className="text-white">
                      <TableCell className="pl-4">
                        <div className="flex items-center">
                          <div className="h-8 w-8 rounded-md bg-primary/20 flex items-center justify-center">
                            {getCategoryIcon(categoryName)}
                          </div>
                          <span className="ml-3">{product.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>{categoryName}</TableCell>
                      <TableCell>{product.unitsRecycled?.toLocaleString() || product.quantity?.toLocaleString() || 0}</TableCell>
                      <TableCell>M {product.revenue?.toLocaleString() || (product.price * product.quantity)?.toLocaleString() || 0}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          {product.growth !== undefined && (
                            <>
                              {product.growth >= 0 ? (
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1 text-primary">
                                  <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 15.75l7.5-7.5 7.5 7.5" />
                                </svg>
                              ) : (
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1 text-accent">
                                  <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
                                </svg>
                              )}
                              <span className={getGrowthColorClass(product.growth)}>
                                {Math.abs(product.growth)}%
                              </span>
                            </>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="pr-4 text-right">
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-white">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
