import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { formatDistanceToNow } from "date-fns";

interface QueriesListProps {
  onReplyClick: (id: number) => void;
}

export default function QueriesList({ onReplyClick }: QueriesListProps) {
  // Fetch customer queries
  const { data: queries, isLoading } = useQuery({
    queryKey: ['/api/sales-queries'],
  });
  
  // Get only pending or recently auto-replied queries (max 3)
  const pendingQueries = queries?.filter(q => q.status === "pending" || q.status === "auto-replied")
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 3);
  
  // Get initials from name
  const getInitials = (name: string) => {
    const names = name.split(' ');
    if (names.length === 1) return names[0].substring(0, 1).toUpperCase();
    return (names[0][0] + names[names.length - 1][0]).toUpperCase();
  };
  
  // Get color class based on query status
  const getStatusColorClass = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-accent/20 text-accent";
      case "auto-replied":
        return "bg-secondary-500/20 text-secondary-500";
      case "completed":
        return "bg-primary/20 text-primary";
      default:
        return "bg-muted text-muted-foreground";
    }
  };
  
  // Get time passed since query was created
  const getTimeAgo = (dateString: string) => {
    return formatDistanceToNow(new Date(dateString), { addSuffix: true });
  };
  
  return (
    <Card className="glass border-none">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-white font-semibold">Pending Customer Queries</CardTitle>
          <Link href="/queries">
            <a className="text-primary text-sm hover:text-primary/80 transition">View All</a>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-24 w-full rounded-lg" />
            <Skeleton className="h-24 w-full rounded-lg" />
            <Skeleton className="h-24 w-full rounded-lg" />
          </div>
        ) : pendingQueries?.length === 0 ? (
          <div className="text-center text-muted-foreground py-6">
            <p>No pending customer queries.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {pendingQueries ? (
              pendingQueries.map((query) => (
                <div key={query.id} className="flex items-start p-3 rounded-lg bg-muted/20">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="bg-secondary-700 text-white">
                      {getInitials(query.name)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="ml-3 flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="text-white font-medium">{query.name}</h4>
                      <span className="text-muted-foreground text-xs">{getTimeAgo(query.createdAt)}</span>
                    </div>
                    <p className="text-muted-foreground text-sm mt-1 line-clamp-2">{query.message}</p>
                    <div className="flex items-center mt-2">
                      <Badge variant="outline" className={getStatusColorClass(query.status)}>
                        {query.status === "pending" ? "Pending" : "Auto-Replied"}
                      </Badge>
                      <Button 
                        variant="link" 
                        size="sm"
                        className="ml-auto text-primary p-0 h-auto"
                        onClick={() => onReplyClick(query.id)}
                      >
                        {query.status === "pending" ? "Reply" : "View"}
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              // Fallback rendering for development when data isn't loaded yet
              [
                { id: 1, name: "Thomas Miller", time: "2h ago", message: "I'm interested in recycling my old server components. Do you accept enterprise-grade equipment?", status: "pending" },
                { id: 2, name: "Sarah Jones", time: "5h ago", message: "What is your process for data destruction on recycled hard drives? I need to ensure all data is securely wiped.", status: "auto-replied" },
                { id: 3, name: "Robert Davis", time: "1d ago", message: "Can you provide a quote for recycling approximately 50 laptops from our office? We're upgrading our equipment.", status: "pending" }
              ].map((item) => (
                <div key={item.id} className="flex items-start p-3 rounded-lg bg-muted/20">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className={item.id === 2 ? "bg-accent-700" : item.id === 3 ? "bg-primary-700" : "bg-secondary-700"}>
                      {getInitials(item.name)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="ml-3 flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="text-white font-medium">{item.name}</h4>
                      <span className="text-muted-foreground text-xs">{item.time}</span>
                    </div>
                    <p className="text-muted-foreground text-sm mt-1 line-clamp-2">{item.message}</p>
                    <div className="flex items-center mt-2">
                      <Badge variant="outline" className={getStatusColorClass(item.status)}>
                        {item.status === "pending" ? "Pending" : "Auto-Replied"}
                      </Badge>
                      <Button 
                        variant="link" 
                        size="sm"
                        className="ml-auto text-primary p-0 h-auto"
                        onClick={() => onReplyClick(item.id)}
                      >
                        {item.status === "pending" ? "Reply" : "View"}
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
