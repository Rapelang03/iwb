import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertCustomerQuerySchema } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, MessageSquareHeart } from "lucide-react";

// Create a schema that extends the insertCustomerQuerySchema
const queryFormSchema = insertCustomerQuerySchema.extend({
  agreement: z.boolean().refine(val => val === true, {
    message: "You must agree to the processing of your data",
  }),
});

// Add type for props
interface QueryModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialData?: {
    id?: number;
    name?: string;
    email?: string;
    message?: string;
  };
  isReply?: boolean;
}

export default function QueryModal({ isOpen, onClose, initialData, isReply = false }: QueryModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Set up form with react-hook-form and zod validation
  const form = useForm<z.infer<typeof queryFormSchema>>({
    resolver: zodResolver(queryFormSchema),
    defaultValues: {
      name: initialData?.name || "",
      email: initialData?.email || "",
      subject: "",
      message: initialData?.message || "",
      agreement: false,
    },
  });
  
  // Handle submission mutation
  const submitMutation = useMutation({
    mutationFn: async (values: z.infer<typeof insertCustomerQuerySchema>) => {
      return apiRequest("POST", "/api/queries", values);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sales-queries'] });
      toast({
        title: "Query submitted",
        description: "We'll get back to you as soon as possible.",
        variant: "default",
      });
      onClose();
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error submitting query",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });
  
  // Handle reply mutation (for updating existing queries)
  const replyMutation = useMutation({
    mutationFn: async ({ id, response }: { id: number, response: string }) => {
      return apiRequest("PUT", `/api/queries/${id}`, {
        status: "completed",
        responseContent: response
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sales-queries'] });
      toast({
        title: "Response sent",
        description: "Your response has been sent to the customer.",
        variant: "default",
      });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error sending response",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });
  
  // Form submission handler
  const onSubmit = (values: z.infer<typeof queryFormSchema>) => {
    setIsSubmitting(true);
    
    // Remove agreement field as it's not part of the API schema
    const { agreement, ...queryData } = values;
    
    if (isReply && initialData?.id) {
      replyMutation.mutate({ 
        id: initialData.id, 
        response: values.message 
      });
    } else {
      submitMutation.mutate(queryData);
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-primary/20 mb-4">
            <MessageSquareHeart className="text-primary h-6 w-6" />
          </div>
          <DialogTitle className="text-center">
            {isReply ? "Reply to Query" : "Submit a Query"}
          </DialogTitle>
          {!isReply && (
            <p className="text-center text-muted-foreground mt-1 text-sm">
              Fill in the form below and our team will get back to you as soon as possible.
            </p>
          )}
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 mt-4">
            {!isReply && (
              <>
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter your full name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="you@example.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="subject"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Subject</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a subject" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="product">Product Information</SelectItem>
                          <SelectItem value="recycling">Recycling Process</SelectItem>
                          <SelectItem value="pricing">Pricing Inquiry</SelectItem>
                          <SelectItem value="support">Technical Support</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </>
            )}
            
            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{isReply ? "Your Response" : "Message"}</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder={isReply ? "Enter your response..." : "How can we help you?"}
                      rows={4} 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {!isReply && (
              <FormField
                control={form.control}
                name="agreement"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel className="text-sm font-normal">
                        I agree to the processing of my data as per your privacy policy.
                      </FormLabel>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />
            )}
            
            <DialogFooter className="mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="w-full sm:w-auto"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="w-full sm:w-auto"
                disabled={submitMutation.isPending || replyMutation.isPending}
              >
                {(submitMutation.isPending || replyMutation.isPending) && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                {isReply ? "Send Response" : "Submit"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
